    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        brand: '#151048',
                        brand2: '#2E1FA6',
                        ink: '#0B0E1A',
                        accent: '#C9A227',
                        'accent-light': '#E8C765',
                        surface: '#F7F7FB',
                        'ink-light': '#161B2E'
                    },
                    fontFamily: {
                        sans: ['Montserrat', 'sans-serif'],
                    },
                    boxShadow: {
                        'soft': '0 1px 2px rgba(10,12,30,0.04), 0 6px 20px -10px rgba(10,12,30,0.18)',
                        'elevated': '0 20px 48px -20px rgba(10,12,30,0.38)',
                    }
                }
            }
        }
    </script>
    <style>
        /* Auto-hide Navbar Transition */
        #main-nav {
            transition: transform 0.3s ease-in-out;
        }
[data-reveal].is-visible {
            opacity: 1;
            transform: translateY(0);
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .animate-fadeInUp {
            animation: fadeInUp 0.5s ease-out forwards;
        }

        /* Accessibility: visible keyboard focus ring on every interactive element */
        /* THEME: smooth color transition across the whole page when toggling light/dark mode */
        body, body *, body *::before, body *::after {
            transition-property: background-color, border-color, color, fill, stroke;
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
            transition-duration: 300ms;
        }
        @media (prefers-reduced-motion: reduce) {
            body, body *, body *::before, body *::after { transition-duration: 0ms !important; }
        }

        a:focus-visible, button:focus-visible, input:focus-visible, textarea:focus-visible, select:focus-visible, [tabindex]:focus-visible {
            outline: 2px solid #C9A227;
            outline-offset: 2px;
            border-radius: 4px;
        }

        /* --- Footer planner/location cards enhancements (formerly scoped to #quote,
             now the cards live inside the footer) --- */
        #footer .q-body { text-align: justify; hyphens: auto; -webkit-hyphens: auto; line-height: 1.7; }
        @keyframes qPulse { 0%,100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.6); opacity: .25; } }
        .q-dot::after { content: ""; position: absolute; inset: 0; border-radius: 9999px; background: #C9A227; animation: qPulse 1.8s cubic-bezier(0.16,1,0.3,1) infinite; }
        #footer .q-card { transition: transform .45s cubic-bezier(0.16,1,0.3,1), box-shadow .45s cubic-bezier(0.16,1,0.3,1); }
        #footer .q-card:hover { transform: translateY(-4px); }
        /* Footer typography — identical on every page. Mirrors the Home page's base text styles so the footer
           looks and wraps the same wherever it appears (low specificity: utility classes still win, like on Home). */
        :where(#footer) h1, :where(#footer) h2, :where(#footer) h3, :where(#footer) h4, :where(#footer) .font-heading { font-family: 'Montserrat', sans-serif; letter-spacing: -0.02em; }
        :where(#footer) p, :where(#footer) blockquote { text-align: left; hyphens: auto; -webkit-hyphens: auto; -ms-hyphens: auto; overflow-wrap: break-word; line-height: 1.7 !important; }
        @media (min-width: 768px) { :where(#footer) p, :where(#footer) blockquote { text-align: justify; } }
/* Project Planner message box: draggable corner with a visible grip */
        .qf-resize-hint { display: none; }
        @media (hover: hover) and (pointer: fine) { .qf-resize-hint { display: block; } }
        #qf-message { resize: vertical; min-height: 140px; max-height: 560px; }
        #qf-message::-webkit-resizer { background: linear-gradient(135deg, transparent 0 52%, rgba(21,16,72,.5) 52% 60%, transparent 60% 72%, rgba(21,16,72,.5) 72% 80%, transparent 80%); border-radius: 0 0 4px 0; }
        /* Short footer caption stays centered/aligned as needed */
        p.footer-caption { text-align: inherit !important; }
        .q-skeleton { background: linear-gradient(100deg, #F7F7FB 20%, #ECECF4 40%, #F7F7FB 60%); background-size: 220% 100%; animation: qShimmer 1.4s linear infinite; }
        @keyframes qShimmer { to { background-position: -220% 0; } }
        .q-frame iframe { position: absolute; inset: 0; width: 100%; height: 100%; z-index: 1; opacity: 0; transition: opacity .6s ease; }
        .q-frame iframe.is-loaded { opacity: 1; }
        #footer .q-btn { transition: transform .3s cubic-bezier(0.16,1,0.3,1), background-color .3s ease, color .3s ease, border-color .3s ease, box-shadow .3s ease; }
        #footer .q-btn:hover { transform: translateY(-2px); }
        #footer .q-btn svg { transition: transform .3s cubic-bezier(0.16,1,0.3,1); }
        #footer .q-btn:hover svg { transform: translateX(2px) translateY(-2px); }
        @media (prefers-reduced-motion: reduce) {
            .q-dot::after, .q-skeleton { animation: none; }
            #footer .q-card:hover, #footer .q-btn:hover { transform: none; }
        }

        /* --- Toast notification (used to confirm quote-form submission) --- */
        #quote-toast {
            transition: opacity .4s cubic-bezier(0.16,1,0.3,1), transform .4s cubic-bezier(0.16,1,0.3,1);
        }
        #quote-toast.hidden-toast { opacity: 0; transform: translateY(8px); pointer-events: none; display: none; }
        /* --- Editorial design-system additions: eyebrow labels, hairline rule,
             restrained numerals --- */
        .eyebrow {
            display: inline-block;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.18em;
            text-transform: uppercase;
            color: #C9A227;
        }
        html.dark .eyebrow { color: #E8C765; }
        .rule-hairline { height: 1px; background: currentColor; opacity: 0.12; }
        .stat-figure { font-family: 'Montserrat', sans-serif; font-weight: 800; letter-spacing: -0.03em; line-height: 1; }

    </style>
    <!-- BRAND BUTTONS: shared styles for .card-link (project/article cards) and .animated-button (View more / See more CTA buttons) -->
    <style id="marra-brand-buttons">
        :root {
            --mb-navy: #151048;
            --mb-navy-2: #2E1FA6;
            --mb-gold: #C9A227;
            --mb-gold-light: #E8C765;
            --mb-ease: cubic-bezier(0.23, 1, 0.32, 1);
        }

        /* ---------- Card links ("View Project" / "Read Article"): navy, turn gold when the card is hovered ---------- */
        .card-link {
            position: relative;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 0;
            margin: 0;
            font-size: 12px;
            font-weight: 600;
            line-height: 1;
            color: var(--mb-navy);
            transition: color .35s var(--mb-ease);
        }
        .dark .card-link { color: #fff; }
        .card-link__arrow {
            width: 16px;
            height: 16px;
            flex: none;
            transition: transform .35s var(--mb-ease);
        }
        @media (hover: hover) and (pointer: fine) {
            .group:hover .card-link { color: var(--mb-gold); }
            .dark .group:hover .card-link { color: var(--mb-gold-light); }
            .group:hover .card-link .card-link__arrow { transform: translateX(4px); }
        }
        .group:focus-visible .card-link { color: var(--mb-gold); }
        .group:focus-visible .card-link .card-link__arrow { transform: translateX(4px); }

        /* ---------- CTA buttons ("View more projects" / "See more Articles"): solid navy pill with arrow ---------- */
        .animated-button {
            position: relative;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            min-height: 48px;
            padding: 14px 32px;
            border: 0;
            border-radius: 999px;
            background-color: var(--mb-navy);
            color: #fff;
            font-size: 15px;
            font-weight: 600;
            line-height: 1;
            white-space: nowrap;
            cursor: pointer;
            box-shadow: 0 1px 2px rgba(10, 12, 30, .08), 0 12px 26px -12px rgba(21, 16, 72, .6);
            -webkit-tap-highlight-color: transparent;
            transition: background-color .3s var(--mb-ease), transform .3s var(--mb-ease), box-shadow .3s var(--mb-ease);
        }
        .animated-button .arr-2,
        .animated-button .circle { display: none; }
        .animated-button .text { position: relative; transform: none; }
        .animated-button svg {
            position: static;
            width: 18px;
            height: 18px;
            flex: none;
            fill: currentColor;
            transition: transform .3s var(--mb-ease);
        }
        .animated-button:active { transform: scale(.97); }
        .animated-button:focus-visible { outline: 2px solid var(--mb-gold); outline-offset: 4px; }
        @media (hover: hover) and (pointer: fine) {
            .animated-button:hover {
                background-color: var(--mb-navy-2);
                transform: translateY(-2px);
                box-shadow: 0 1px 2px rgba(10, 12, 30, .08), 0 18px 32px -14px rgba(46, 31, 166, .65);
            }
            .animated-button:hover .arr-1 { transform: translateX(4px); }
        }
        .animated-button:focus-visible .arr-1 { transform: translateX(4px); }
        /* Dark mode: gold pill so it stands out on the dark background */
        .dark .animated-button { background-color: var(--mb-gold-light); color: var(--mb-navy); box-shadow: 0 12px 26px -12px rgba(0, 0, 0, .7); }
        @media (hover: hover) and (pointer: fine) { .dark .animated-button:hover { background-color: #fff; } }

        @media (max-width: 400px) {
            .animated-button { padding: 14px 26px; font-size: 14px; }
        }
        @media (prefers-reduced-motion: reduce) {
            .card-link, .card-link__arrow, .animated-button, .animated-button svg { transition: none !important; }
            .animated-button:hover, .animated-button:active { transform: none; }
        }
    </style>

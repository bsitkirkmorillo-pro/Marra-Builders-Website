    <footer id="footer" class="bg-brand text-white pt-16 pb-16 md:pb-20 border-t border-white/10 text-left scroll-mt-20">
        <div class="max-w-7xl mx-auto px-6 lg:px-12">

            <h2 class="sr-only">Request a Quote &amp; Find Our Office</h2>

            <div class="grid lg:grid-cols-12 gap-12 lg:gap-14 items-start">

                <!-- LEFT SIDE GRID: Project Planner card + Location card -->
                <div class="lg:col-span-8 grid sm:grid-cols-2 gap-6 lg:gap-8 items-stretch">

                    <!-- PROJECT PLANNER -->
                    <div class="q-card group bg-white border border-black/[0.08] rounded-md shadow-soft hover:shadow-elevated overflow-hidden flex flex-col animate-fadeInUp dark:bg-ink-light dark:border-white/10" data-reveal>
                        <div class="flex items-start justify-between gap-4 border-b border-black/[0.06] bg-surface/70 dark:bg-ink-light/70 px-6 md:px-8 py-5 dark:border-white/10">
                            <div>
                                <h3 class="font-heading text-lg md:text-xl font-bold text-brand tracking-tight dark:text-accent-light">Project Planner</h3>
                                <p class="text-[11px] uppercase tracking-[0.16em] text-slate-400 mt-1 dark:text-slate-500" style="text-align:left !important;">Digital Intake Form</p>
                            </div>
                        </div>

                        <div class="p-6 md:p-8 flex flex-col flex-1">

                            <form id="quote-form" novalidate class="flex flex-col gap-4 flex-1">
                                <input type="checkbox" name="botcheck" class="hidden" style="display:none" tabindex="-1" autocomplete="off">

                                <div>
                                    <label for="qf-name" class="block text-xs font-semibold uppercase tracking-wide text-brand mb-1.5 dark:text-accent-light">Full Name</label>
                                    <input type="text" id="qf-name" name="name" autocomplete="name" required
                                        class="qf-input w-full rounded-md border border-black/[0.08] bg-surface px-4 py-2.5 text-sm text-ink placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition-colors duration-200 dark:border-white/10 dark:bg-ink-light dark:text-white dark:placeholder:text-slate-500"
                                        placeholder="Juan Dela Cruz">
                                    <p class="qf-error hidden mt-1.5 text-xs font-medium text-red-600" data-error-for="qf-name">Please enter your full name.</p>
                                </div>

                                <div class="grid grid-cols-1 gap-4">
                                    <div>
                                        <label for="qf-email" class="block text-xs font-semibold uppercase tracking-wide text-brand mb-1.5 dark:text-accent-light">Email Address</label>
                                        <input type="email" id="qf-email" name="email" autocomplete="email" required
                                            class="qf-input w-full rounded-md border border-black/[0.08] bg-surface px-4 py-2.5 text-sm text-ink placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition-colors duration-200 dark:border-white/10 dark:bg-ink-light dark:text-white dark:placeholder:text-slate-500"
                                            placeholder="you@email.com">
                                        <p class="qf-error hidden mt-1.5 text-xs font-medium text-red-600" data-error-for="qf-email">Please enter a valid email address.</p>
                                    </div>
                                    <div>
                                        <label for="qf-phone" class="block text-xs font-semibold uppercase tracking-wide text-brand mb-1.5 dark:text-accent-light">Phone Number</label>
                                        <input type="tel" id="qf-phone" name="phone" autocomplete="tel" required
                                            class="qf-input w-full rounded-md border border-black/[0.08] bg-surface px-4 py-2.5 text-sm text-ink placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition-colors duration-200 dark:border-white/10 dark:bg-ink-light dark:text-white dark:placeholder:text-slate-500"
                                            placeholder="+63 9XX XXX XXXX">
                                        <p class="qf-error hidden mt-1.5 text-xs font-medium text-red-600" data-error-for="qf-phone">Please enter a valid phone number.</p>
                                    </div>
                                </div>

                                <div>
                                    <label for="qf-project-type" class="block text-xs font-semibold uppercase tracking-wide text-brand mb-1.5 dark:text-accent-light">Project Type</label>
                                    <div class="relative">
                                        <select id="qf-project-type" name="project_type" required
                                            class="qf-input w-full appearance-none rounded-md border border-black/[0.08] bg-surface px-4 py-2.5 pr-10 text-sm text-ink focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition-colors duration-200 dark:border-white/10 dark:bg-ink-light dark:text-white">
                                            <option value="" disabled selected hidden>Select a project type</option>
                                            <option value="Ports and Harbors">Ports and Harbors</option>
                                            <option value="Dredging">Dredging</option>
                                            <option value="General Engineering">General Engineering</option>
                                            <option value="General Building">General Building</option>
                                            <option value="Other">Other</option>
                                        </select>
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-brand/60 dark:text-accent-light/60"><path d="m6 9 6 6 6-6"/></svg>
                                    </div>
                                    <p class="qf-error hidden mt-1.5 text-xs font-medium text-red-600" data-error-for="qf-project-type">Please select a project type.</p>
                                </div>

                                <div class="flex flex-col">
                                    <label for="qf-message" class="block text-xs font-semibold uppercase tracking-wide text-brand mb-1.5 dark:text-accent-light">Project Details / Message</label>
                                    <textarea id="qf-message" name="message" rows="5" required
                                        class="qf-input w-full min-h-[140px] resize-y rounded-md border border-black/[0.08] bg-surface px-4 py-2.5 text-sm text-ink placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent transition-colors duration-200 dark:border-white/10 dark:bg-ink-light dark:text-white dark:placeholder:text-slate-500"
                                        placeholder="Tell us about your project: location, scope and target timeline."></textarea>
                                    <p class="qf-resize-hint mt-1.5 text-right text-[10px] text-slate-400 dark:text-slate-500">Drag the bottom-right corner to make the box bigger.</p>
                                    <p class="qf-error hidden mt-1.5 text-xs font-medium text-red-600" data-error-for="qf-message">Please share a few details about your project.</p>
                                </div>

                                <p id="qf-form-error" class="hidden text-xs font-medium text-red-600 -mt-1">Something went wrong sending your request. Please try again, or call the office directly.</p>

                                <button type="submit" id="qf-submit"
                                    class="q-btn inline-flex items-center justify-center gap-2 rounded-md bg-brand px-5 py-3 text-sm font-semibold text-white hover:bg-brand2 hover:shadow-soft transition-all duration-300 disabled:opacity-60 disabled:cursor-not-allowed disabled:hover:bg-brand active:scale-95 disabled:active:scale-100 cursor-pointer disabled:cursor-not-allowed min-h-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2">
                                    <svg id="qf-spinner" class="hidden h-4 w-4 animate-spin" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 0 1 8-8V0C5.373 0 0 5.373 0 12h4Z"></path></svg>
                                    <span id="qf-submit-label">Send Project Details</span>
                                    <svg id="qf-submit-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
                                </button>
                                <p class="text-[11px] leading-relaxed text-slate-500 dark:text-slate-400" style="hyphens:none;-webkit-hyphens:none;text-align:left" data-cms="home.planner.note"><?php echo marra_text('home.planner.note'); ?></p>
                            </form>

                            <!-- Submission confirmation toast — shown once the custom form's fetch()
                                 request to /api/contact succeeds. -->
                            <div id="quote-toast" class="hidden-toast mt-4 flex items-start gap-3 rounded-md border border-accent/25 bg-accent/[0.08] px-4 py-3" role="status" aria-live="polite">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4 mt-0.5 shrink-0 text-brand dark:text-accent-light"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/></svg>
                                <p class="text-xs text-brand font-medium leading-relaxed dark:text-accent-light">Thanks — your project details are in. Our estimators will reach out with next steps.</p>
                            </div>
                        </div>
                    </div>

                    <!-- LOCATION -->
                    <div class="q-card group bg-white border border-black/[0.08] rounded-md shadow-soft hover:shadow-elevated overflow-hidden flex flex-col animate-fadeInUp dark:bg-ink-light dark:border-white/10" data-reveal>
                        <div class="flex items-start justify-between gap-4 border-b border-black/[0.06] bg-surface/70 dark:bg-ink-light/70 px-6 md:px-8 py-5 dark:border-white/10">
                            <div>
                                <h3 class="font-heading text-lg md:text-xl font-bold text-brand tracking-tight dark:text-accent-light">Our Location</h3>
                                <p class="text-[11px] uppercase tracking-[0.16em] text-slate-400 mt-1 dark:text-slate-500" style="text-align:left !important;">Headquarters &amp; Depot</p>
                            </div>
                        </div>

                        <div class="p-6 md:p-8 flex flex-col flex-1">

                            <div class="q-frame relative rounded-md overflow-hidden border border-black/[0.06] bg-surface flex-1 min-h-[420px] dark:border-white/10 dark:bg-ink-light">
                                <div class="q-skeleton absolute inset-0 z-0 flex items-center justify-center" aria-hidden="true">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="h-8 w-8 text-slate-300"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                                </div>
                                <iframe src="https://www.google.com/maps?q=Marra%20Builders%20Inc.%20blk%2042%20lot%202%2C%2048%20Daanghari%20St%2C%20Navotas%2C%201485%20Metro%20Manila%2C%20Philippines&output=embed" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="w-full h-full" onload="this.classList.add('is-loaded')"></iframe>
                            </div>

                            <div class="mt-auto pt-5 border-t border-black/[0.06] flex flex-wrap items-center gap-3 dark:border-white/10" style="margin-top:1.5rem;">
                                <a href="https://www.google.com/maps/search/?api=1&query=Marra%20Builders%20Inc.%20blk%2042%20lot%202%2C%2048%20Daanghari%20St%2C%20Navotas%2C%201485%20Metro%20Manila%2C%20Philippines" target="_blank" rel="noopener"
                                   class="q-btn inline-flex items-center gap-2 rounded-md border border-brand/15 bg-white px-4 py-2.5 text-xs font-semibold text-brand hover:bg-brand hover:text-white hover:border-brand hover:shadow-soft transition-all duration-200 active:scale-95 cursor-pointer min-h-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 dark:bg-ink-light dark:text-accent-light">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"/></svg>
                                    Open in Google Maps
                                </a>
                                <a href="tel:+63-2 8351 1101" class="q-btn inline-flex items-center gap-2 rounded-md border border-black/[0.08] bg-surface px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-brand hover:border-brand/20 hover:bg-white transition-all duration-200 active:scale-95 cursor-pointer min-h-[44px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 dark:border-white/10 dark:bg-ink-light dark:text-slate-300 dark:hover:text-accent-light dark:hover:bg-ink-light">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92Z"/></svg>
                                    Call the office
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- RIGHT COLUMN: Brand / Contact Info / Accreditations -->
                <div class="lg:col-span-4 space-y-10">

                    <!-- Brand -->
                    <div class="space-y-4" data-reveal>
                        <img src="<?php echo esc_url(MARRA_ASSETS); ?>png/marra-builders-large-white.png" alt="Marra Builders Inc." class="h-10 w-auto" loading="lazy">
                        <p class="text-xs text-slate-200 leading-relaxed max-w-xs">
                            PCAB Category 'AAA' accredited general engineering firm specializing in marine infrastructure, ports, and harbors across the Philippines.
                        </p>
                    </div>

                    <!-- Contact Info -->
                    <div data-reveal>
                        <h4 class="font-heading text-xs font-bold uppercase tracking-[0.14em] text-accent-light mb-5">Contact Info</h4>
                        <ul class="space-y-3 text-xs text-slate-200 leading-relaxed">
                            <li><strong class="text-white">Address:</strong><br><span data-cms="site.address"><?php echo marra_text('site.address'); ?></span></li>
                            <li><strong class="text-white">Email:</strong><br><span data-cms="site.emails"><?php echo marra_text('site.emails'); ?></span></li>
                            <li><strong class="text-white">Phone:</strong><br><span data-cms="site.phones"><?php echo marra_text('site.phones'); ?></span></li>
                        </ul>
                    </div>

                    <!-- Accreditations -->
                    <div data-reveal>
                        <h4 class="font-heading text-xs font-bold uppercase tracking-[0.14em] text-accent-light mb-5">Accreditations</h4>
                        <p class="text-xs text-slate-200 leading-relaxed mb-4">
                            PCAB Category AAA | Large B for Ports & Harbors | ISO 9001:2015
                        </p>
                        <div class="flex flex-wrap items-center gap-4">
                            <img src="<?php echo esc_url(MARRA_ASSETS); ?>png/PCAB.png" alt="PCAB" class="h-12 w-auto opacity-80 hover:opacity-100 transition-opacity" loading="lazy">
                            <img src="<?php echo esc_url(MARRA_ASSETS); ?>png/iso.png" alt="ISO" class="h-12 w-auto opacity-80 hover:opacity-100 transition-opacity" loading="lazy">
                            <img src="<?php echo esc_url(MARRA_ASSETS); ?>png/Philgeps.png" alt="PhilGEPS" class="h-12 w-auto opacity-80 hover:opacity-100 transition-opacity" loading="lazy">
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bottom Bar -->
            <div class="mt-12 lg:mt-16 pt-6 border-t border-white/10 flex flex-col md:flex-row justify-between items-center text-xs text-slate-400 gap-4 dark:text-slate-500">
                <p class="footer-caption text-center md:text-left">&copy; <?php echo esc_html(wp_date('Y')); ?> Marra Builders Inc. All rights reserved.</p>
                <p class="footer-caption text-center md:text-right">Bringing our islands closer together, one port at a time.</p>
            </div>
        </div>
    </footer>

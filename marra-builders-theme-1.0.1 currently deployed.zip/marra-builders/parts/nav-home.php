
    <!-- MAIN NAVIGATION BAR -->
    <header id="main-nav" data-state="top" class="fixed top-0 left-0 w-full z-50">

        <div class="max-w-7xl mx-auto px-6 lg:px-12 h-[60px] flex items-center justify-between gap-5">

            <!-- Brand / Logo -->
            <a href="<?php echo esc_url(marra_url('home')); ?>" class="flex items-center gap-3 group">
                <span class="relative inline-flex items-center h-10 transition-transform duration-300 group-hover:scale-105">

                    <img
                        src="<?php echo esc_url(MARRA_ASSETS); ?>png/marra-builders-large-white.png"
                        alt="Marra Builders Inc."
                        class="nav-logo nav-logo-white h-10 w-auto">

                    <img
                        src="<?php echo esc_url(MARRA_ASSETS); ?>png/marra-builders-large-black.png"
                        alt="Marra Builders Inc."
                        class="nav-logo nav-logo-black h-10 w-auto absolute inset-0">

                </span>
            </a>


            <!-- RIGHT SIDE -->
            <div class="flex items-center gap-3 md:gap-5">

                <!-- Light/Dark Mode Toggle -->
                <!-- KEEP THIS ID: theme-toggle -->
                <button
                    id="theme-toggle"
                    type="button"
                    aria-label="Toggle dark mode"
                    class="nav-icon-btn inline-flex items-center justify-center h-11 w-11 min-h-[44px] min-w-[44px] rounded-lg active:scale-90 transition-transform duration-200 cursor-pointer">

                    <!-- Sun Icon -->
                    <svg
                        data-theme-icon="sun"
                        class="hidden h-5 w-5 transition-transform duration-200 hover:scale-110 hover:rotate-12"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round">

                        <circle cx="12" cy="12" r="4"></circle>

                        <path d="M12 2v2"></path>
                        <path d="M12 20v2"></path>
                        <path d="M4.93 4.93l1.41 1.41"></path>
                        <path d="M17.66 17.66l1.41 1.41"></path>
                        <path d="M2 12h2"></path>
                        <path d="M20 12h2"></path>
                        <path d="M6.34 17.66l-1.41 1.41"></path>
                        <path d="M19.07 4.93l-1.41 1.41"></path>

                    </svg>

                    <!-- Moon Icon -->
                    <svg
                        data-theme-icon="moon"
                        class="h-5 w-5 transition-transform duration-200 hover:scale-110 hover:-rotate-12"
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round">

                        <path d="M21 12.79A9 9 0 1 1 11.21 3
                                7 7 0 0 0 21 12.79Z">
                        </path>

                    </svg>

                </button>


                <!-- DESKTOP NAVIGATION -->
                <nav class="hidden md:flex items-center space-x-9 text-[12.5px] font-semibold uppercase tracking-[0.09em]">

                    <a
                        href="<?php echo esc_url(marra_url('home')); ?>"
                        aria-current="page"
                        class="nav-link relative transition-colors duration-200
                            after:absolute after:left-0 after:-bottom-1
                            after:h-0.5 after:w-0 after:bg-accent
                            after:transition-all after:duration-300
                            hover:after:w-full">
                        Home
                    </a>

                    <a
                        href="<?php echo esc_url(marra_url('home')); ?>#about"
                        class="nav-link relative transition-colors duration-200
                            after:absolute after:left-0 after:-bottom-1
                            after:h-0.5 after:w-0 after:bg-accent
                            after:transition-all after:duration-300
                            hover:after:w-full">
                        About
                    </a>

                    <a
                        href="<?php echo esc_url(marra_url('home')); ?>#services"
                        class="nav-link relative transition-colors duration-200
                            after:absolute after:left-0 after:-bottom-1
                            after:h-0.5 after:w-0 after:bg-accent
                            after:transition-all after:duration-300
                            hover:after:w-full">
                        Services
                    </a>

                    <a
                        href="<?php echo esc_url(marra_url('projects')); ?>"
                        class="nav-link relative transition-colors duration-200
                            after:absolute after:left-0 after:-bottom-1
                            after:h-0.5 after:w-0 after:bg-accent
                            after:transition-all after:duration-300
                            hover:after:w-full">
                        Projects
                    </a>

                    <a
                        href="<?php echo esc_url(marra_url('articles')); ?>"
                        class="nav-link relative transition-colors duration-200
                            after:absolute after:left-0 after:-bottom-1
                            after:h-0.5 after:w-0 after:bg-accent
                            after:transition-all after:duration-300
                            hover:after:w-full">
                        Articles
                    </a>

                    <a
                        href="#footer"
                        class="nav-link relative transition-colors duration-200
                            after:absolute after:left-0 after:-bottom-1
                            after:h-0.5 after:w-0 after:bg-accent
                            after:transition-all after:duration-300
                            hover:after:w-full">
                        Contact Us
                    </a>

                </nav>


                <!-- MOBILE MENU BUTTON -->
                <button
                    id="mobile-menu-btn"
                    type="button"
                    class="nav-icon-btn md:hidden focus:outline-none p-2
                        min-h-[44px] min-w-[44px]
                        flex items-center justify-center
                        rounded-lg cursor-pointer
                        transition-transform duration-200 active:scale-90"
                    aria-label="Toggle Menu">

                    <svg
                        class="w-6 h-6"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24">

                        <!-- Hamburger -->
                        <path
                            id="menu-icon-bars"
                            class="block"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16">
                        </path>

                        <!-- Close -->
                        <path
                            id="menu-icon-close"
                            class="hidden"
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M6 18L18 6M6 6l12 12">
                        </path>

                    </svg>

                </button>

            </div>

        </div>


        <!-- MOBILE DROPDOWN MENU -->
        <div
            id="mobile-menu"
            class="hidden md:hidden bg-white border-b border-black/[0.06]
                px-6 py-6 shadow-xl space-y-4 text-left
                dark:bg-ink-light dark:border-white/10">

            <a
                href="<?php echo esc_url(marra_url('home')); ?>"
                aria-current="page"
                class="block text-slate-600 hover:text-brand font-medium mobile-link
                    py-2.5 px-2 -mx-2 rounded-lg transition-colors duration-150
                    hover:bg-slate-50 active:bg-slate-100
                    min-h-[44px] flex items-center cursor-pointer
                    dark:text-slate-300 dark:hover:text-accent-light
                    dark:hover:bg-ink-light dark:active:bg-ink-light">
                Home
            </a>

            <a
                href="<?php echo esc_url(marra_url('home')); ?>#about"
                class="block text-slate-600 hover:text-brand font-medium mobile-link
                    py-2.5 px-2 -mx-2 rounded-lg transition-colors duration-150
                    hover:bg-slate-50 active:bg-slate-100
                    min-h-[44px] flex items-center cursor-pointer
                    dark:text-slate-300 dark:hover:text-accent-light
                    dark:hover:bg-ink-light dark:active:bg-ink-light">
                About
            </a>

            <a
                href="<?php echo esc_url(marra_url('home')); ?>#services"
                class="block text-slate-600 hover:text-brand font-medium mobile-link
                    py-2.5 px-2 -mx-2 rounded-lg transition-colors duration-150
                    hover:bg-slate-50 active:bg-slate-100
                    min-h-[44px] flex items-center cursor-pointer
                    dark:text-slate-300 dark:hover:text-accent-light
                    dark:hover:bg-ink-light dark:active:bg-ink-light">
                Services
            </a>

            <a
                href="<?php echo esc_url(marra_url('projects')); ?>"
                class="block text-slate-600 hover:text-brand font-medium mobile-link
                    py-2.5 px-2 -mx-2 rounded-lg transition-colors duration-150
                    hover:bg-slate-50 active:bg-slate-100
                    min-h-[44px] flex items-center cursor-pointer
                    dark:text-slate-300 dark:hover:text-accent-light
                    dark:hover:bg-ink-light dark:active:bg-ink-light">
                Projects
            </a>

            <a
                href="<?php echo esc_url(marra_url('articles')); ?>"
                class="block text-slate-600 hover:text-brand font-medium mobile-link
                    py-2.5 px-2 -mx-2 rounded-lg transition-colors duration-150
                    hover:bg-slate-50 active:bg-slate-100
                    min-h-[44px] flex items-center cursor-pointer
                    dark:text-slate-300 dark:hover:text-accent-light
                    dark:hover:bg-ink-light dark:active:bg-ink-light">
                Articles
            </a>

            <a
                href="#footer"
                class="block text-slate-600 hover:text-brand font-medium mobile-link
                    py-2.5 px-2 -mx-2 rounded-lg transition-colors duration-150
                    hover:bg-slate-50 active:bg-slate-100
                    min-h-[44px] flex items-center cursor-pointer
                    dark:text-slate-300 dark:hover:text-accent-light
                    dark:hover:bg-ink-light dark:active:bg-ink-light">
                Contact Us
            </a>

        </div>

    </header>

    <!-- VIDEO HERO -->
    <header id="hero-header" class="relative w-full bg-slate-950 overflow-hidden flex items-center justify-center">
        <!-- The page previously had no <h1> anywhere — every heading started at
             h2. This is the primary on-page SEO signal for the homepage, so it's
             added here as real (if visually hidden) text rather than baked into
             the hero video, which carries no text to a crawler or screen reader. -->
        <h1 class="sr-only">Marra Builders Inc. — Marine Civil Engineering Contractor in Navotas City, Philippines</h1>
        <!-- Scrim: keeps nav links legible over bright frames of the video -->
        <div class="absolute top-0 left-0 w-full h-40 bg-gradient-to-b from-black/55 via-black/20 to-transparent pointer-events-none z-10"></div>
        <video
            id="hero-video-fg"
            class="w-full h-auto object-contain block pointer-events-none"
            role="presentation"
            autoplay
            muted
            playsinline
            loop
            poster="<?php echo esc_url(MARRA_ASSETS); ?>png/marra-builders-white.png">
            <source src="<?php echo esc_url(MARRA_ASSETS); ?>videos/Who-We-Are.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </header>



    <!-- PAGE HEADER -->
    <header class="relative pt-36 md:pt-44 pb-20 md:pb-28 bg-ink text-white overflow-hidden text-left">
        <div class="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1541888946425-d0fbb186a5b7?q=80&w=1200')] bg-cover bg-center opacity-[0.14] [filter:grayscale(0.4)]"></div>
        <div class="absolute inset-0 bg-gradient-to-br from-brand/95 via-ink to-ink"></div>
        <div class="relative max-w-6xl mx-auto px-6 text-left">
            <h1 class="font-heading text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.05] max-w-2xl" data-reveal>&middot; Journal News &amp; Updates</h1>
        </div>
    </header>

    <!-- ARTICLES GRID -->
    <section class="py-24 bg-surface text-left dark:bg-ink-light">
        <div class="max-w-6xl mx-auto px-6 text-left">
            <div id="article-grid" class="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 text-left">
<?php marra_render_article_grid(); ?>
            </div>
        </div>
    </section>

    <!-- FOOTER -->

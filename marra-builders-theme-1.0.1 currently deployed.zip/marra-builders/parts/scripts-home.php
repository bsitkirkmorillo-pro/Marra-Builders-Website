    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const mainNav = document.getElementById('main-nav');
            const heroHeader = document.getElementById('hero-header');

            // Nav stays transparent (bg faded, buttons/links stay visible) while the
            // hero video is still behind it; goes solid once the page has scrolled past it.
            if (mainNav && heroHeader) {
                const updateNavState = () => {
                    const navHeight = mainNav.offsetHeight;
                    const heroBottom = heroHeader.offsetTop + heroHeader.offsetHeight;
                    const shouldBeSolid = window.scrollY >= (heroBottom - navHeight);
                    mainNav.dataset.state = shouldBeSolid ? 'scrolled' : 'top';
                };
                updateNavState();
                window.addEventListener('scroll', updateNavState, { passive: true });
                window.addEventListener('resize', updateNavState);
            }

            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mobileMenu = document.getElementById('mobile-menu');
            const iconBars = document.getElementById('menu-icon-bars');
            const iconClose = document.getElementById('menu-icon-close');
            const mobileLinks = document.querySelectorAll('.mobile-link');

            // Company Profile video modal — opens on "View Video", autoplays, closes on
            // the close button, backdrop click, or Escape, and pauses playback on close.
            const videoBtn = document.getElementById('view-video-btn');
            const videoModal = document.getElementById('video-modal');
            const videoModalBackdrop = document.getElementById('video-modal-backdrop');
            const videoModalClose = document.getElementById('video-modal-close');
            const companyVideo = document.getElementById('company-profile-video');

            const openVideoModal = () => {
                if (!videoModal) return;
                videoModal.classList.remove('hidden');
                videoModal.classList.add('flex');
                videoModal.setAttribute('aria-hidden', 'false');
                document.body.classList.add('overflow-hidden');
                if (companyVideo) {
                    companyVideo.currentTime = 0;
                    companyVideo.play().catch(() => {});
                }
            };
            const closeVideoModal = () => {
                if (!videoModal) return;
                videoModal.classList.add('hidden');
                videoModal.classList.remove('flex');
                videoModal.setAttribute('aria-hidden', 'true');
                document.body.classList.remove('overflow-hidden');
                if (companyVideo) companyVideo.pause();
            };

            videoBtn?.addEventListener('click', openVideoModal);
            videoModalClose?.addEventListener('click', closeVideoModal);
            videoModalBackdrop?.addEventListener('click', closeVideoModal);
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && videoModal && !videoModal.classList.contains('hidden')) {
                    closeVideoModal();
                }
            });

            // Mobile Menu Toggle Logic
            if (mobileMenuBtn && mobileMenu) {
                mobileMenuBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const isHidden = mobileMenu.classList.contains('hidden');

                    if (isHidden) {
                        mobileMenu.classList.remove('hidden');
                        iconBars?.classList.add('hidden');
                        iconBars?.classList.remove('block');
                        iconClose?.classList.remove('hidden');
                        iconClose?.classList.add('block');
                    } else {
                        mobileMenu.classList.add('hidden');
                        iconBars?.classList.remove('hidden');
                        iconBars?.classList.add('block');
                        iconClose?.classList.add('hidden');
                        iconClose?.classList.remove('block');
                    }
                });

                // Auto-close mobile menu when tapping a link
                mobileLinks.forEach(link => {
                    link.addEventListener('click', () => {
                        mobileMenu.classList.add('hidden');
                        iconBars?.classList.remove('hidden');
                        iconBars?.classList.add('block');
                        iconClose?.classList.add('hidden');
                        iconClose?.classList.remove('block');
                    });
                });
            }
        });
    </script>


    <!-- ABOUT SECTION -->
    <section id="about" class="py-24 bg-white border-b border-black/[0.06] scroll-mt-20 text-left dark:bg-ink-light dark:border-white/10">
        <div class="max-w-6xl mx-auto px-6">
            
            <div class="grid lg:grid-cols-2 gap-12 items-center mb-16">
                <!-- Left Side: Section Title & Text -->
                <div class="text-left" data-reveal>
                        <h2 class="font-heading text-3xl sm:text-4xl font-extrabold tracking-tight mb-6 text-brand text-left dark:text-accent-light" data-cms="home.about.title"><?php echo marra_text('home.about.title'); ?></h2>                    <div class="text-slate-600 text-base leading-relaxed space-y-4 text-left dark:text-slate-300">
                        <p class="text-left" data-cms="home.about.p1"><?php echo marra_text('home.about.p1'); ?></p>
                        <p class="text-left" data-cms="home.about.p2"><?php echo marra_text('home.about.p2'); ?></p>
                        <p class="text-left" data-cms="home.about.p3"><?php echo marra_text('home.about.p3'); ?></p>
                        <p class="font-semibold text-slate-800 text-left dark:text-white" data-cms="home.about.p4"><?php echo marra_text('home.about.p4'); ?></p>
                    </div>
                </div>

                <!-- Right Side: Location Map -->
                <!-- Theme-aware 3D flip card: navy map on the front face, gold map on the back face.
                     JS toggles rotateY(180deg) on #map-flip-inner whenever the theme changes. -->
                <div class="w-full [perspective:1600px]" data-reveal>
                    <div class="w-full transition-transform duration-300 ease-in-out hover:scale-[1.02]">
                        <div id="map-flip-inner" class="grid w-full transition-transform duration-700 ease-in-out [transform-style:preserve-3d]">
                            <img 
                                src="<?php echo esc_url(MARRA_ASSETS); ?>png/map.png" 
                                alt="Marra Builders Location Map" 
                                class="col-start-1 row-start-1 w-full h-auto block [backface-visibility:hidden]" 
                                loading="lazy"
                            />
                            <img 
                                src="<?php echo esc_url(MARRA_ASSETS); ?>png/map-light.png" 
                                alt="Marra Builders Location Map" 
                                class="col-start-1 row-start-1 w-full h-auto block [backface-visibility:hidden] [transform:rotateY(180deg)]" 
                                loading="lazy"
                            />
                        </div>
                    </div>
                </div>
            </div>

            <!-- Mission & Vision -->
            <div class="grid md:grid-cols-2 gap-10 md:gap-14 pt-12 border-t border-black/[0.08] dark:border-white/10 text-left">
                <div data-reveal>
                    <p class="eyebrow mb-3">Mission</p>
                    <p class="text-slate-600 text-sm sm:text-base leading-relaxed text-left dark:text-slate-300" data-cms="home.mission"><?php echo marra_text('home.mission'); ?></p>
                </div>

                <div data-reveal>
                    <p class="eyebrow mb-3">Vision</p>
                    <p class="text-slate-600 text-sm sm:text-base leading-relaxed text-left dark:text-slate-300" data-cms="home.vision"><?php echo marra_text('home.vision'); ?></p>
                </div>
            </div>

        </div>
    </section>


    <!-- SERVICES SECTION -->
    <section id="services" class="py-24 bg-white border-y border-black/[0.08] text-left dark:bg-ink-light dark:border-white/10">
        <div class="max-w-6xl mx-auto px-6 text-left">
            <div class="grid lg:grid-cols-12 gap-10 lg:gap-14 mb-6" data-reveal>
                <div class="lg:col-span-4">
                    <p class="eyebrow mb-3">Capabilities</p>
                    <h2 class="font-heading text-4xl sm:text-5xl font-extrabold tracking-tight text-brand dark:text-accent-light">Our Services</h2>
                </div>
            </div>

            <div class="divide-y divide-black/[0.08] dark:divide-white/10 border-t border-black/[0.08] dark:border-white/10">

                <!-- Ports and Harbors -->
                <div data-reveal class="group grid md:grid-cols-12 gap-6 md:gap-10 items-center py-10">
                    <span class="stat-figure hidden md:block md:col-span-1 text-3xl text-slate-200 dark:text-white/10">01</span>
                    <div class="md:col-span-4 flex items-center gap-4">
                        <div class="w-10 h-10 shrink-0 bg-brand dark:bg-accent-light transition-transform duration-300 group-hover:scale-105"
                            style="-webkit-mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/ports-and-harbors.png');mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/ports-and-harbors.png');-webkit-mask-size:contain;mask-size:contain;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;"
                            role="img"
                            aria-label="Ports and Harbors icon">
                        </div>
                        <h3 class="font-heading text-xl sm:text-2xl font-bold text-ink text-left dark:text-white" data-cms="home.services.1.title"><?php echo marra_text('home.services.1.title'); ?></h3>
                    </div>
                    <p class="md:col-span-7 text-slate-600 text-base leading-relaxed text-left dark:text-slate-300" data-cms="home.services.1.text"><?php echo marra_text('home.services.1.text'); ?></p>
                </div>

                <!-- Dredging -->
                <div data-reveal class="group grid md:grid-cols-12 gap-6 md:gap-10 items-center py-10">
                    <span class="stat-figure hidden md:block md:col-span-1 text-3xl text-slate-200 dark:text-white/10">02</span>
                    <div class="md:col-span-4 flex items-center gap-4">
                        <div class="w-10 h-10 shrink-0 bg-brand dark:bg-accent-light transition-transform duration-300 group-hover:scale-105"
                            style="-webkit-mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/dredging.png');mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/dredging.png');-webkit-mask-size:contain;mask-size:contain;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;"
                            role="img"
                            aria-label="Dredging icon">
                        </div>
                        <h3 class="font-heading text-xl sm:text-2xl font-bold text-ink text-left dark:text-white" data-cms="home.services.2.title"><?php echo marra_text('home.services.2.title'); ?></h3>
                    </div>
                    <p class="md:col-span-7 text-slate-600 text-base leading-relaxed text-left dark:text-slate-300" data-cms="home.services.2.text"><?php echo marra_text('home.services.2.text'); ?></p>
                </div>

                <!-- General Engineering -->
                <div data-reveal class="group grid md:grid-cols-12 gap-6 md:gap-10 items-center py-10">
                    <span class="stat-figure hidden md:block md:col-span-1 text-3xl text-slate-200 dark:text-white/10">03</span>
                    <div class="md:col-span-4 flex items-center gap-4">
                        <div class="w-10 h-10 shrink-0 bg-brand dark:bg-accent-light transition-transform duration-300 group-hover:scale-105"
                            style="-webkit-mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/general-engineering.png');mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/general-engineering.png');-webkit-mask-size:contain;mask-size:contain;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;"
                            role="img"
                            aria-label="General Engineering icon">
                        </div>
                        <h3 class="font-heading text-xl sm:text-2xl font-bold text-ink text-left dark:text-white" data-cms="home.services.3.title"><?php echo marra_text('home.services.3.title'); ?></h3>
                    </div>
                    <p class="md:col-span-7 text-slate-600 text-base leading-relaxed text-left dark:text-slate-300" data-cms="home.services.3.text"><?php echo marra_text('home.services.3.text'); ?></p>
                </div>

                <!-- General Building -->
                <div data-reveal class="group grid md:grid-cols-12 gap-6 md:gap-10 items-center py-10">
                    <span class="stat-figure hidden md:block md:col-span-1 text-3xl text-slate-200 dark:text-white/10">04</span>
                    <div class="md:col-span-4 flex items-center gap-4">
                        <div class="w-10 h-10 shrink-0 bg-brand dark:bg-accent-light transition-transform duration-300 group-hover:scale-105"
                            style="-webkit-mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/general-building.png');mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/general-building.png');-webkit-mask-size:contain;mask-size:contain;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;"
                            role="img"
                            aria-label="General Building icon">
                        </div>
                        <h3 class="font-heading text-xl sm:text-2xl font-bold text-ink text-left dark:text-white" data-cms="home.services.4.title"><?php echo marra_text('home.services.4.title'); ?></h3>
                    </div>
                    <p class="md:col-span-7 text-slate-600 text-base leading-relaxed text-left dark:text-slate-300" data-cms="home.services.4.text"><?php echo marra_text('home.services.4.text'); ?></p>
                </div>

            </div>
        </div>
    </section>


    <!-- PROJECTS SECTION (preview, managed from /admin) -->
    <section id="projects" class="py-24 bg-surface text-left scroll-mt-20 dark:bg-ink-light">
        <div class="max-w-6xl mx-auto px-6 text-left">
            <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16 text-left" data-reveal>
                <div class="text-left max-w-xl">
                    <p class="eyebrow mb-3">Selected Work</p>
                    <h2 class="font-heading text-4xl sm:text-5xl font-extrabold tracking-tight text-brand text-left dark:text-accent-light">Our Projects</h2>
                </div>
            </div>

            <div id="projects-preview-grid" class="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 text-left">
<?php marra_render_home_projects(); ?>
            </div>

            <div class="mt-14 flex justify-center" data-reveal>
                <a href="<?php echo esc_url(marra_url('projects')); ?>" class="animated-button focus-visible:outline-none">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="arr-2" aria-hidden="true"><path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z"></path></svg>
                    <span class="text">View more projects</span>
                    <span class="circle"></span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="arr-1" aria-hidden="true"><path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z"></path></svg>
                </a>
            </div>
        </div>
    </section>

    <!-- COMPANY PROFILE VIDEO MODAL -->
    <div id="video-modal" class="hidden fixed inset-0 z-[100] items-center justify-center p-4 md:p-8" aria-hidden="true">
        <div id="video-modal-backdrop" class="absolute inset-0 bg-ink/90 backdrop-blur-sm"></div>
        <div class="video-modal-panel relative w-full max-w-4xl mx-auto" role="dialog" aria-modal="true" aria-label="Company Profile video">
            <button id="video-modal-close" type="button" aria-label="Close video" class="absolute -top-11 right-0 md:-top-2 md:-right-12 text-white/80 hover:text-white transition-all duration-200 p-2 hover:scale-110 active:scale-90 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70 focus-visible:ring-offset-2 focus-visible:ring-offset-black/40">
                <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
            <div class="relative rounded-md overflow-hidden shadow-elevated bg-black aspect-video">
                <video id="company-profile-video" class="w-full h-full" controls playsinline preload="none">
                    <source src="<?php echo esc_url(MARRA_ASSETS); ?>videos/Company-Profile.mp4" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </div>
        </div>
    </div>


    <!-- CERTIFICATION & ACCREDITATION SECTION -->
    <section id="certifications" class="relative py-24 bg-white border-y border-black/[0.06] overflow-hidden text-left dark:bg-ink-light dark:border-white/10">

        <div class="absolute top-10 left-8 w-14 h-14 text-accent/[0.08] dark:text-accent-light/[0.08] cert-shape rotate-12" data-depth="0.6">
            <svg viewBox="0 0 100 100" class="w-full h-full fill-current"><polygon points="50,4 96,94 4,94"/></svg>
        </div>
        <div class="absolute top-20 right-16 w-9 h-9 text-accent/[0.08] dark:text-accent-light/[0.08] cert-shape -rotate-6" data-depth="1.2">
            <svg viewBox="0 0 100 100" class="w-full h-full fill-current"><polygon points="50,4 96,94 4,94"/></svg>
        </div>
        <div class="absolute top-1/3 left-1/4 w-6 h-6 text-accent/[0.08] dark:text-accent-light/[0.08] cert-shape rotate-45" data-depth="1.5">
            <svg viewBox="0 0 100 100" class="w-full h-full fill-current"><polygon points="50,4 96,94 4,94"/></svg>
        </div>
        <div class="absolute bottom-24 right-1/4 w-20 h-20 text-accent/[0.08] dark:text-accent-light/[0.08] cert-shape -rotate-12" data-depth="0.35">
            <svg viewBox="0 0 100 100" class="w-full h-full fill-current"><polygon points="50,4 96,94 4,94"/></svg>
        </div>
        <div class="absolute bottom-14 left-14 w-11 h-11 text-accent/[0.08] dark:text-accent-light/[0.08] cert-shape rotate-90" data-depth="0.9">
            <svg viewBox="0 0 100 100" class="w-full h-full fill-current"><polygon points="50,4 96,94 4,94"/></svg>
        </div>
        <div class="absolute top-1/2 right-8 w-16 h-16 text-accent/[0.08] dark:text-accent-light/[0.08] cert-shape -rotate-45" data-depth="0.5">
            <svg viewBox="0 0 100 100" class="w-full h-full fill-current"><polygon points="50,4 96,94 4,94"/></svg>
        </div>
        <div class="absolute bottom-8 right-1/3 w-7 h-7 text-accent/[0.08] dark:text-accent-light/[0.08] cert-shape rotate-3" data-depth="1.3">
            <svg viewBox="0 0 100 100" class="w-full h-full fill-current"><polygon points="50,4 96,94 4,94"/></svg>
        </div>

        <div class="relative max-w-6xl mx-auto px-6 text-left">
            <div class="max-w-xl mb-16" data-reveal>
                <h2 class="font-heading text-4xl sm:text-5xl font-extrabold tracking-tight text-brand text-left dark:text-accent-light">
                    Certification &amp; Accreditation
                </h2>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8 items-start pt-10 border-t border-black/[0.08] dark:border-white/10">
                <!-- ISO Certification -->
                <div class="flex flex-col items-center text-center" data-reveal>
                    <img 
                        src="<?php echo esc_url(MARRA_ASSETS); ?>png/iso.png" 
                        alt="ISO 9001:2015 Certification" 
                        class="h-36 w-auto object-contain transition-all duration-300 ease-in-out hover:scale-105 hover:drop-shadow-xl cursor-pointer"
                        loading="lazy"
                    >
                    <p class="text-xs text-slate-600 mt-5 leading-relaxed max-w-[220px] dark:text-slate-300">
                        ISO Certified: 19th September 2026 &ndash; ISO 9001:2015
                    </p>
                </div>

                <!-- PCAB Accreditation -->
                <div class="flex flex-col items-center text-center" data-reveal>
                    <img 
                        src="<?php echo esc_url(MARRA_ASSETS); ?>png/PCAB.png" 
                        alt="PCAB Accreditation" 
                        class="h-36 w-auto object-contain transition-all duration-300 ease-in-out hover:scale-105 hover:drop-shadow-xl cursor-pointer"
                        loading="lazy"
                    >
                    <p class="text-xs text-slate-600 mt-5 leading-relaxed max-w-[260px] dark:text-slate-300">
                        We have been duly accredited by the Philippine Contractors Accreditation Board (PCAB) under category &ldquo;AAA&rdquo; for General Building, and is currently registered as a &ldquo;Large B&rdquo; for Ports and Harbors
                    </p>
                </div>

                <!-- PHILGEPS Membership -->
                <div class="flex flex-col items-center text-center" data-reveal>
                    <img 
                        src="<?php echo esc_url(MARRA_ASSETS); ?>png/Philgeps.png" 
                        alt="PHILGEPS Platinum Membership" 
                        class="h-36 w-auto object-contain transition-all duration-300 ease-in-out hover:scale-105 hover:drop-shadow-xl cursor-pointer"
                        loading="lazy"
                    >
                    <p class="text-xs text-slate-600 mt-5 leading-relaxed max-w-[220px] dark:text-slate-300">
                        PHILGEPS Registered: Platinum Membership
                    </p>
                </div>
            </div>
        </div>
    </section>

    <style>
        .cert-shape {
            transition: transform 0.15s ease-out;
            will-change: transform;
            pointer-events: none;
        }
    </style>

    <script>
        (function () {
            const certSection = document.getElementById('certifications');
            const certShapes = certSection ? certSection.querySelectorAll('.cert-shape') : [];

            if (certSection && certShapes.length) {
                const restTilt = (shape) => {
                    const depth = parseFloat(shape.dataset.depth) || 1;
                    const rotateX = 10 * depth;
                    const rotateY = -10 * depth;
                    shape.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
                };

                certShapes.forEach(restTilt);

                certSection.addEventListener('mousemove', (e) => {
                    const rect = certSection.getBoundingClientRect();
                    const x = (e.clientX - rect.left) / rect.width - 0.5;
                    const y = (e.clientY - rect.top) / rect.height - 0.5;

                    certShapes.forEach((shape) => {
                        const depth = parseFloat(shape.dataset.depth) || 1;
                        const moveX = x * -50 * depth;
                        const moveY = y * -50 * depth;

                        shape.style.transform = `translate3d(${moveX}px, ${moveY}px, 0px)`;
                    });
                });

                certSection.addEventListener('mouseleave', () => {
                    certShapes.forEach(restTilt);
                });
            }
        })();
    </script>

    <!-- VALUES SECTION -->
    <section id="values" class="py-24 bg-white text-left dark:bg-ink-light">
        <div class="max-w-6xl mx-auto px-6 text-left">
            <div class="grid lg:grid-cols-12 gap-10 lg:gap-14 mb-14 lg:mb-16">
                <div class="lg:col-span-4" data-reveal>
                    <p class="eyebrow mb-3">What Drives Us</p>
                    <h2 class="font-heading text-3xl sm:text-4xl font-extrabold tracking-tight text-brand dark:text-accent-light">Our Values</h2>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-10 text-left">

                <!-- Excellence -->
                <div data-reveal class="h-full">
                    <div class="group flex flex-col items-start text-left h-full pt-7 border-t-2 border-black/[0.08] transition-colors duration-300 hover:border-accent dark:border-white/10">
                        <div class="w-11 h-11 mb-5 bg-brand dark:bg-accent-light transition-transform duration-300 group-hover:scale-110" style="-webkit-mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/excellence.png');mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/excellence.png');-webkit-mask-size:contain;mask-size:contain;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;" role="img" aria-label="Excellence icon"></div>
                        <h3 class="font-heading text-lg font-bold text-ink mb-2.5 text-left dark:text-white" data-cms="home.values.1.title"><?php echo marra_text('home.values.1.title'); ?></h3>
                        <p class="text-slate-600 text-sm leading-relaxed dark:text-slate-300" data-cms="home.values.1.text"><?php echo marra_text('home.values.1.text'); ?></p>
                    </div>
                </div>

                <!-- Innovation -->
                <div data-reveal class="h-full">
                    <div class="group flex flex-col items-start text-left h-full pt-7 border-t-2 border-black/[0.08] transition-colors duration-300 hover:border-accent dark:border-white/10">
                        <div class="w-11 h-11 mb-5 bg-brand dark:bg-accent-light transition-transform duration-300 group-hover:scale-110" style="-webkit-mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/innovation.png');mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/innovation.png');-webkit-mask-size:contain;mask-size:contain;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;" role="img" aria-label="Innovation icon"></div>
                        <h3 class="font-heading text-lg font-bold text-ink mb-2.5 text-left dark:text-white" data-cms="home.values.2.title"><?php echo marra_text('home.values.2.title'); ?></h3>
                        <p class="text-slate-600 text-sm leading-relaxed dark:text-slate-300" data-cms="home.values.2.text"><?php echo marra_text('home.values.2.text'); ?></p>
                    </div>
                </div>

                <!-- Teamwork -->
                <div data-reveal class="h-full">
                    <div class="group flex flex-col items-start text-left h-full pt-7 border-t-2 border-black/[0.08] transition-colors duration-300 hover:border-accent dark:border-white/10">
                        <div class="w-11 h-11 mb-5 bg-brand dark:bg-accent-light transition-transform duration-300 group-hover:scale-110" style="-webkit-mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/teamwork.png');mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/teamwork.png');-webkit-mask-size:contain;mask-size:contain;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;" role="img" aria-label="Teamwork icon"></div>
                        <h3 class="font-heading text-lg font-bold text-ink mb-2.5 text-left dark:text-white" data-cms="home.values.3.title"><?php echo marra_text('home.values.3.title'); ?></h3>
                        <p class="text-slate-600 text-sm leading-relaxed dark:text-slate-300" data-cms="home.values.3.text"><?php echo marra_text('home.values.3.text'); ?></p>
                    </div>
                </div>

                <!-- Integrity -->
                <div data-reveal class="h-full">
                    <div class="group flex flex-col items-start text-left h-full pt-7 border-t-2 border-black/[0.08] transition-colors duration-300 hover:border-accent dark:border-white/10">
                        <div class="w-11 h-11 mb-5 bg-brand dark:bg-accent-light transition-transform duration-300 group-hover:scale-110" style="-webkit-mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/integrity.png');mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/integrity.png');-webkit-mask-size:contain;mask-size:contain;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;" role="img" aria-label="Integrity icon"></div>
                        <h3 class="font-heading text-lg font-bold text-ink mb-2.5 text-left dark:text-white" data-cms="home.values.4.title"><?php echo marra_text('home.values.4.title'); ?></h3>
                        <p class="text-slate-600 text-sm leading-relaxed dark:text-slate-300" data-cms="home.values.4.text"><?php echo marra_text('home.values.4.text'); ?></p>
                    </div>
                </div>

                <!-- Genuine Care -->
                <div data-reveal class="h-full">
                    <div class="group flex flex-col items-start text-left h-full pt-7 border-t-2 border-black/[0.08] transition-colors duration-300 hover:border-accent dark:border-white/10">
                        <div class="w-11 h-11 mb-5 bg-brand dark:bg-accent-light transition-transform duration-300 group-hover:scale-110" style="-webkit-mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/genuine-care.png');mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/genuine-care.png');-webkit-mask-size:contain;mask-size:contain;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;" role="img" aria-label="Genuine Care icon"></div>
                        <h3 class="font-heading text-lg font-bold text-ink mb-2.5 text-left dark:text-white" data-cms="home.values.5.title"><?php echo marra_text('home.values.5.title'); ?></h3>
                        <p class="text-slate-600 text-sm leading-relaxed dark:text-slate-300" data-cms="home.values.5.text"><?php echo marra_text('home.values.5.text'); ?></p>
                    </div>
                </div>

                <!-- Community -->
                <div data-reveal class="h-full">
                    <div class="group flex flex-col items-start text-left h-full pt-7 border-t-2 border-black/[0.08] transition-colors duration-300 hover:border-accent dark:border-white/10">
                        <div class="w-11 h-11 mb-5 bg-brand dark:bg-accent-light transition-transform duration-300 group-hover:scale-110" style="-webkit-mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/community.png');mask-image:url('<?php echo esc_url(MARRA_ASSETS); ?>png/community.png');-webkit-mask-size:contain;mask-size:contain;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;-webkit-mask-position:center;mask-position:center;" role="img" aria-label="Community icon"></div>
                        <h3 class="font-heading text-lg font-bold text-ink mb-2.5 text-left dark:text-white" data-cms="home.values.6.title"><?php echo marra_text('home.values.6.title'); ?></h3>
                        <p class="text-slate-600 text-sm leading-relaxed dark:text-slate-300" data-cms="home.values.6.text"><?php echo marra_text('home.values.6.text'); ?></p>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- ARTICLES SECTION (preview, managed from /admin) -->
    <section id="articles" class="py-24 bg-white border-y border-black/[0.06] text-left scroll-mt-20 dark:bg-ink-light dark:border-white/10">
        <div class="max-w-6xl mx-auto px-6 text-left">
            <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16 text-left" data-reveal>
                <div class="text-left max-w-xl">
                    <h2 class="font-heading text-4xl sm:text-5xl font-extrabold tracking-tight mb-4 text-brand text-left dark:text-accent-light">Latest Updates</h2>
                </div>
            </div>

            <div id="articles-preview-grid" class="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 text-left">
<?php marra_render_home_articles(); ?>
            </div>

            <div class="mt-14 flex justify-center" data-reveal>
                <a href="<?php echo esc_url(marra_url('articles')); ?>" class="animated-button focus-visible:outline-none">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="arr-2" aria-hidden="true"><path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z"></path></svg>
                    <span class="text">See more Articles</span>
                    <span class="circle"></span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="arr-1" aria-hidden="true"><path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z"></path></svg>
                </a>
            </div>
        </div>
    </section>


    <!-- FOOTER (includes the Project Planner form + Location map, formerly a separate
         "#quote" section — now integrated as the footer's right-side grid) -->

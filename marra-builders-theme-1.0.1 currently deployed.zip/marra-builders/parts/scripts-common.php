    <script>
        (function () {
            const revealEls = document.querySelectorAll('[data-reveal]');
            if (!revealEls.length || !('IntersectionObserver' in window)) {
                revealEls.forEach(el => el.classList.add('is-visible'));
                return;
            }
            const io = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const siblings = entry.target.parentElement
                            ? Array.from(entry.target.parentElement.children).filter(c => c.hasAttribute('data-reveal'))
                            : [];
                        const idx = siblings.indexOf(entry.target);
                        if (idx > 0) {
                            entry.target.style.transitionDelay = Math.min(idx * 70, 420) + 'ms';
                        }
                        entry.target.classList.add('is-visible');
                        io.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
            revealEls.forEach(el => io.observe(el));
        })();
    </script>

    <!-- QUOTE FORM: client-side validation + submission to this site's own /api/contact endpoint.
         Messages are stored in the admin inbox (/admin) — no third-party service involved. Shows inline field errors, a disabled/spinner submit state, and
         the existing success toast on completion. -->
    <script>
        (function () {
            const form = document.getElementById('quote-form');
            if (!form) return;

            const toast = document.getElementById('quote-toast');
            // Message box: also grows while typing (corner-dragging is not available on most phones). Never shrinks a box the visitor enlarged.
            const msgBox = document.getElementById('qf-message');
            if (msgBox) msgBox.addEventListener('input', function () {
                if (msgBox.scrollHeight > msgBox.clientHeight) msgBox.style.height = Math.min(msgBox.scrollHeight + 2, 560) + 'px';
            });
            const formError = document.getElementById('qf-form-error');
            const submitBtn = document.getElementById('qf-submit');
            const submitLabel = document.getElementById('qf-submit-label');
            const submitIcon = document.getElementById('qf-submit-icon');
            const spinner = document.getElementById('qf-spinner');

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const phonePattern = /^[0-9+()\-\s]{7,20}$/;

            const fields = {
                'qf-name': (v) => v.trim().length > 0,
                'qf-email': (v) => emailPattern.test(v.trim()),
                'qf-phone': (v) => phonePattern.test(v.trim()),
                'qf-project-type': (v) => v.trim().length > 0,
                'qf-message': (v) => v.trim().length > 0
            };

            function setFieldValid(id, isValid) {
                const input = document.getElementById(id);
                const errorEl = form.querySelector('[data-error-for="' + id + '"]');
                if (!input) return;
                if (isValid) {
                    input.classList.remove('border-red-400', 'focus:ring-red-300');
                    if (errorEl) errorEl.classList.add('hidden');
                } else {
                    input.classList.add('border-red-400', 'focus:ring-red-300');
                    if (errorEl) errorEl.classList.remove('hidden');
                }
            }

            function validateField(id) {
                const input = document.getElementById(id);
                const isValid = fields[id](input.value);
                setFieldValid(id, isValid);
                return isValid;
            }

            function validateForm() {
                let allValid = true;
                Object.keys(fields).forEach((id) => {
                    if (!validateField(id)) allValid = false;
                });
                return allValid;
            }

            // Validate on blur, and clear an error as soon as a field becomes valid again.
            Object.keys(fields).forEach((id) => {
                const input = document.getElementById(id);
                if (!input) return;
                input.addEventListener('blur', () => validateField(id));
                input.addEventListener('input', () => {
                    if (fields[id](input.value)) setFieldValid(id, true);
                });
            });

            function setLoading(isLoading) {
                submitBtn.disabled = isLoading;
                spinner.classList.toggle('hidden', !isLoading);
                submitIcon.classList.toggle('hidden', isLoading);
                submitLabel.textContent = isLoading ? 'Sending…' : 'Send Project Details';
            }

            form.addEventListener('submit', function (e) {
                e.preventDefault();
                formError.classList.add('hidden');
                toast.classList.add('hidden-toast');

                if (!validateForm()) {
                    const firstInvalid = form.querySelector('.border-red-400');
                    if (firstInvalid) firstInvalid.focus();
                    return;
                }

                setLoading(true);

                var fd = new FormData(form);
                fd.append('action', 'marra_contact');
                fetch((window.MARRA && window.MARRA.ajaxUrl) || '/wp-admin/admin-ajax.php', {
                    method: 'POST',
                    body: fd,
                    credentials: 'same-origin'
                })
                    .then((res) => res.json())
                    .then((data) => {
                        setLoading(false);
                        if (data && data.success) {
                            form.reset();
                            toast.classList.remove('hidden-toast');
                            toast.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                        } else {
                            formError.classList.remove('hidden');
                        }
                    })
                    .catch(() => {
                        setLoading(false);
                        formError.classList.remove('hidden');
                    });
            });
        })();
    </script>

    <script>
        (function () {
            var root = document.documentElement;
            var btn = document.getElementById('theme-toggle');
            if (!btn) return;
            var sunIcons = document.querySelectorAll('[data-theme-icon="sun"]');
            var moonIcons = document.querySelectorAll('[data-theme-icon="moon"]');
            var mapFlip = document.getElementById('map-flip-inner');

            function syncIcons() {
                var isDark = root.classList.contains('dark');
                sunIcons.forEach(function (el) { el.classList.toggle('hidden', !isDark); });
                moonIcons.forEach(function (el) { el.classList.toggle('hidden', isDark); });
            }
            syncIcons();

            function syncMapFlip() {
                if (!mapFlip) return;
                var isDark = root.classList.contains('dark');
                mapFlip.style.transform = isDark ? 'rotateY(180deg)' : 'rotateY(0deg)';
            }
            syncMapFlip();

            btn.addEventListener('click', function () {
                var isDark = root.classList.toggle('dark');
                try { localStorage.setItem('theme', isDark ? 'dark' : 'light'); } catch (e) {}
                syncIcons();
                syncMapFlip();
                var activeIcon = btn.querySelector('svg:not(.hidden)');
                if (activeIcon) {
                    activeIcon.classList.add('scale-125', 'rotate-180');
                    setTimeout(function () {
                        activeIcon.classList.remove('scale-125', 'rotate-180');
                    }, 200);
                }
            });
        })();
    </script>

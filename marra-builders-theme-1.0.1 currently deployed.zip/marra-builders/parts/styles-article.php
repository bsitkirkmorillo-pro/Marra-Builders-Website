    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        brand: '#151048',
                        brand2: '#2E1FA6',
                        ink: '#0B0E1A',
                        accent: '#C9A227',
                        'accent-light': '#E8C765',
                        surface: '#F7F7FB',
                        'ink-light': '#161B2E'
                    },
                    fontFamily: {
                        sans: ['Montserrat', 'sans-serif'],
                        heading: ['Montserrat', 'sans-serif']
                    },
                    boxShadow: {
                        soft: '0 1px 2px rgba(10,12,30,0.04), 0 6px 20px -10px rgba(10,12,30,0.18)',
                        elevated: '0 20px 48px -20px rgba(10,12,30,0.38)'
                    },
                    keyframes: {
                        fadeInUp: {
                            '0%': { opacity: 0, transform: 'translateY(18px)' },
                            '100%': { opacity: 1, transform: 'translateY(0)' }
                        }
                    },
                    animation: {
                        fadeInUp: 'fadeInUp 0.7s cubic-bezier(0.16,1,0.3,1) both'
                    }
                }
            }
        };
    </script>

    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            text-align: left;
        }

        h1, h2, h3, h4, .font-heading {
            font-family: 'Montserrat', sans-serif;
            letter-spacing: -0.02em;
        }

        #main-nav {
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            will-change: transform, opacity;
        }

        #main-nav.nav-hidden {
            transform: translateY(-100%);
            opacity: 0;
            pointer-events: none;
        }

        #main-nav.nav-hidden:hover {
            transform: translateY(0);
            opacity: 1;
            pointer-events: auto;
        }

        [data-reveal] {
            opacity: 0;
            transform: translateY(20px);
            transition: opacity .7s cubic-bezier(0.16,1,0.3,1), transform .7s cubic-bezier(0.16,1,0.3,1);
        }
        [data-reveal].is-visible {
            opacity: 1;
            transform: translateY(0);
        }

        p, blockquote {
            text-align: left;
            hyphens: auto;
            -webkit-hyphens: auto;
            -ms-hyphens: auto;
            overflow-wrap: break-word;
            line-height: 1.7 !important;
        }
        @media (min-width: 768px) {
            p, blockquote { text-align: justify; }
        }

        /* Short footer caption stays centered/aligned as needed */
        p.footer-caption {
            text-align: inherit !important;
        }

        /* Accessibility: visible keyboard focus ring on every interactive element */
        /* THEME: smooth color transition across the whole page when toggling light/dark mode */
        body, body *, body *::before, body *::after {
            transition-property: background-color, border-color, color, fill, stroke;
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
            transition-duration: 300ms;
        }
        @media (prefers-reduced-motion: reduce) {
            body, body *, body *::before, body *::after { transition-duration: 0ms !important; }
        }

        a:focus-visible, button:focus-visible, input:focus-visible, textarea:focus-visible, select:focus-visible, [tabindex]:focus-visible {
            outline: 2px solid #C9A227;
            outline-offset: 2px;
            border-radius: 4px;
        }

        /* Skeleton shimmer used while the article record is fetched from the sheet */
        .skel-shimmer {
            background: linear-gradient(100deg, #E2E8F0 20%, #EDF1F5 40%, #E2E8F0 60%);
            background-size: 220% 100%;
            animation: skelShimmer 1.4s linear infinite;
        }
        @keyframes skelShimmer { to { background-position: -220% 0; } }
        @media (prefers-reduced-motion: reduce) {
            .skel-shimmer { animation: none; }
        }

        /* --- Footer planner/location cards enhancements (formerly scoped to #quote,
             now the cards live inside the footer) --- */
        #footer .q-body { text-align: justify; hyphens: auto; -webkit-hyphens: auto; line-height: 1.7; }
        @keyframes qPulse { 0%,100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.6); opacity: .25; } }
        .q-dot::after { content: ""; position: absolute; inset: 0; border-radius: 9999px; background: #C9A227; animation: qPulse 1.8s cubic-bezier(0.16,1,0.3,1) infinite; }
        #footer .q-card { transition: transform .45s cubic-bezier(0.16,1,0.3,1), box-shadow .45s cubic-bezier(0.16,1,0.3,1); }
        #footer .q-card:hover { transform: translateY(-4px); }
        /* Footer typography — identical on every page. Mirrors the Home page's base text styles so the footer
           looks and wraps the same wherever it appears (low specificity: utility classes still win, like on Home). */
        :where(#footer) h1, :where(#footer) h2, :where(#footer) h3, :where(#footer) h4, :where(#footer) .font-heading { font-family: 'Montserrat', sans-serif; letter-spacing: -0.02em; }
        :where(#footer) p, :where(#footer) blockquote { text-align: left; hyphens: auto; -webkit-hyphens: auto; -ms-hyphens: auto; overflow-wrap: break-word; line-height: 1.7 !important; }
        @media (min-width: 768px) { :where(#footer) p, :where(#footer) blockquote { text-align: justify; } }
/* Project Planner message box: draggable corner with a visible grip */
        .qf-resize-hint { display: none; }
        @media (hover: hover) and (pointer: fine) { .qf-resize-hint { display: block; } }
        #qf-message { resize: vertical; min-height: 140px; max-height: 560px; }
        #qf-message::-webkit-resizer { background: linear-gradient(135deg, transparent 0 52%, rgba(21,16,72,.5) 52% 60%, transparent 60% 72%, rgba(21,16,72,.5) 72% 80%, transparent 80%); border-radius: 0 0 4px 0; }
        .q-skeleton { background: linear-gradient(100deg, #F7F7FB 20%, #ECECF4 40%, #F7F7FB 60%); background-size: 220% 100%; animation: qShimmer 1.4s linear infinite; }
        @keyframes qShimmer { to { background-position: -220% 0; } }
        .q-frame iframe { position: absolute; inset: 0; width: 100%; height: 100%; z-index: 1; opacity: 0; transition: opacity .6s ease; }
        .q-frame iframe.is-loaded { opacity: 1; }
        #footer .q-btn { transition: transform .3s cubic-bezier(0.16,1,0.3,1), background-color .3s ease, color .3s ease, border-color .3s ease, box-shadow .3s ease; }
        #footer .q-btn:hover { transform: translateY(-2px); }
        #footer .q-btn svg { transition: transform .3s cubic-bezier(0.16,1,0.3,1); }
        #footer .q-btn:hover svg { transform: translateX(2px) translateY(-2px); }
        @media (prefers-reduced-motion: reduce) {
            .q-dot::after, .q-skeleton { animation: none; }
            #footer .q-card:hover, #footer .q-btn:hover { transform: none; }
        }

        /* --- Toast notification (used to confirm quote-form submission) --- */
        #quote-toast {
            transition: opacity .4s cubic-bezier(0.16,1,0.3,1), transform .4s cubic-bezier(0.16,1,0.3,1);
        }
        #quote-toast.hidden-toast { opacity: 0; transform: translateY(8px); pointer-events: none; display: none; }
        /* --- Editorial design-system additions: eyebrow labels, hairline rule,
             restrained numerals --- */
        .eyebrow {
            display: inline-block;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.18em;
            text-transform: uppercase;
            color: #C9A227;
        }
        html.dark .eyebrow { color: #E8C765; }
        .rule-hairline { height: 1px; background: currentColor; opacity: 0.12; }
        .stat-figure { font-family: 'Montserrat', sans-serif; font-weight: 800; letter-spacing: -0.03em; line-height: 1; }

    </style>
    <!-- BACK BUTTON: navy block expands over the button on hover -->
    <style id="marra-back-button">
        .back-button {
            --bb-green: #151048;
            position: relative;
            display: inline-flex;
            align-items: center;
            height: 56px;
            padding: 0 28px 0 68px;
            border-radius: 16px;
            background: #fff;
            color: #000;
            font-size: 18px;
            font-weight: 600;
            line-height: 1;
            white-space: nowrap;
            cursor: pointer;
            box-shadow: 0 1px 2px rgba(10,12,30,.08), 0 6px 20px -10px rgba(10,12,30,.35);
            -webkit-tap-highlight-color: transparent;
            transition: transform .2s ease;
        }
        .back-button__icon {
            position: absolute;
            left: 4px;
            top: 4px;
            z-index: 10;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: var(--bb-green);
            transition: width .5s ease;
        }
        .back-button__icon svg { width: 25px; height: 25px; flex: none; }
        .back-button__icon svg path { fill: #fff; }
        .back-button:active { transform: scale(.96); }
        .back-button:focus-visible { outline: 2px solid var(--bb-green); outline-offset: 4px; }
        .back-button:focus-visible .back-button__icon { width: calc(100% - 8px); }
        @media (hover: hover) and (pointer: fine) {
            .back-button:hover .back-button__icon { width: calc(100% - 8px); }
        }
        @media (prefers-reduced-motion: reduce) {
            .back-button, .back-button__icon { transition: none; }
        }
    </style>

<?php
// Server-rendered detail page (replaces the old JavaScript rendering).
$pid   = get_the_ID();
$title = get_the_title();
$loc   = marra_location( $pid );
$ids   = marra_image_ids( $pid );
$hero  = $ids ? wp_get_attachment_image_url( $ids[0], 'full' ) : '';
list( $lead, $rest ) = marra_split_description( get_post_field( 'post_content', $pid ) );
$date  = get_the_date( 'F j, Y', $pid );
?>
    <!-- PAGE HEADER -->
    <header class="relative pt-36 md:pt-44 pb-16 md:pb-20 bg-ink text-white overflow-hidden text-left">
        <div id="header-bg" class="absolute inset-0 bg-cover bg-center opacity-[0.14] [filter:grayscale(0.4)]" style="<?php echo $hero ? 'background-image:url(\'' . esc_url($hero) . '\')' : ''; ?>"></div>
        <div class="absolute inset-0 bg-gradient-to-br from-brand/95 via-ink to-ink"></div>
        <div class="relative max-w-6xl mx-auto px-6 text-left">
            <a href="<?php echo esc_url(marra_url('articles')); ?>" class="group inline-flex items-center gap-2 text-slate-300 hover:text-accent transition-colors duration-200 text-sm font-medium mb-5 cursor-pointer">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 transition-transform duration-200 group-hover:-translate-x-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M17 10a.75.75 0 01-.75.75H5.612l4.158 3.96a.75.75 0 11-1.04 1.08l-5.5-5.25a.75.75 0 010-1.08l5.5-5.25a.75.75 0 111.04 1.08L5.612 9.25H16.25A.75.75 0 0117 10z" clip-rule="evenodd" />
                </svg>
                Back to Articles
            </a>
            <h1 id="header-title" class="font-heading text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight leading-[1.05] text-left max-w-3xl"><?php echo esc_html($title); ?></h1>
            <div class="rule-hairline w-16 mt-7 mb-4 text-white/40"></div>
            <span id="header-category" class="eyebrow"><?php echo esc_html($loc !== '' ? $loc : html_entity_decode('News &amp; Insights')); ?></span>
        </div>
    </header>

    <!-- ARTICLE DETAIL CONTENT -->
    <section class="py-20 bg-surface text-left dark:bg-ink-light">
        <div class="max-w-5xl mx-auto px-6 text-left">

            <div id="article-content">

                <!-- H2: keeps the heading order h1 -> h2 -> h3 unbroken (the footer
                     cards further down use h3). Visually this still reads as plain
                     body copy, so it's sized like one, not styled like a heading.
                -->
                <h2 class="sr-only">Article Overview</h2>

                <!-- ARTICLE META -->
                <div class="max-w-3xl">
                    <span id="article-date" class="eyebrow block mb-5"><?php echo esc_html($date); ?></span>
                </div>

                <!-- FIRST PARAGRAPH -->
                <div class="max-w-3xl">
                    <p id="article-description-lead" class="text-slate-700 text-lg leading-relaxed text-left whitespace-pre-line dark:text-slate-200"><?php echo esc_html($lead); ?></p>
                </div>

                <!-- IMAGE COLUMN -->
                <div id="article-gallery" class="flex flex-col gap-6 mt-10" role="group" aria-label="Article photos">
<?php marra_render_gallery($ids, $title, $loc); ?>
                </div>

                <!-- REMAINING PARAGRAPHS -->
                <div id="article-description-rest" class="max-w-3xl mt-10 space-y-6 text-slate-600 leading-relaxed text-left whitespace-pre-line dark:text-slate-300"><?php foreach ($rest as $para) : ?><p class="whitespace-pre-line"><?php echo esc_html($para); ?></p><?php endforeach; ?></div>

                <div class="mt-10">
                    <a href="<?php echo esc_url(marra_url('articles')); ?>" class="back-button">
                        <span class="back-button__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" aria-hidden="true"><path d="M224 480h640a32 32 0 1 1 0 64H224a32 32 0 0 1 0-64z" fill="#000000"></path><path d="m237.248 512 265.408 265.344a32 32 0 0 1-45.312 45.312l-288-288a32 32 0 0 1 0-45.312l288-288a32 32 0 1 1 45.312 45.312L237.248 512z" fill="#000000"></path></svg></span>
                        <span class="back-button__label">Back to Articles</span>
                    </a>
                </div>

            </div>

        </div>
    </section>


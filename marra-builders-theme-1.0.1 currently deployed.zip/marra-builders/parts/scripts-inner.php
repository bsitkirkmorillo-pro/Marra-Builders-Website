    <script>
        // MOBILE MENU TOGGLE
        const mobileBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        const iconBars = document.getElementById('menu-icon-bars');
        const iconClose = document.getElementById('menu-icon-close');

        if (mobileBtn && mobileMenu && iconBars && iconClose) {
            mobileBtn.addEventListener('click', () => {
                const isOpen = !mobileMenu.classList.contains('hidden');
                mobileMenu.classList.toggle('hidden', isOpen);
                iconBars.classList.toggle('hidden', !isOpen);
                iconBars.classList.toggle('block', isOpen);
                iconClose.classList.toggle('hidden', isOpen);
                iconClose.classList.toggle('block', !isOpen);
            });

            mobileMenu.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    mobileMenu.classList.add('hidden');
                    iconBars.classList.remove('hidden');
                    iconBars.classList.add('block');
                    iconClose.classList.remove('block');
                    iconClose.classList.add('hidden');
                });
            });
        }

        const mainNav = document.getElementById('main-nav');
        const navTrigger = document.getElementById('nav-hover-trigger');
        let lastScrollY = window.scrollY;

        window.addEventListener('scroll', () => {
            const currentScrollY = window.scrollY;
            if (currentScrollY > 80 && currentScrollY > lastScrollY) {
                mainNav.classList.add('nav-hidden');
            } else {
                if (currentScrollY <= 80) {
                    mainNav.classList.remove('nav-hidden');
                }
            }
            lastScrollY = currentScrollY;
        });

        if (navTrigger && mainNav) {
            navTrigger.addEventListener('mouseenter', () => {
                mainNav.classList.remove('nav-hidden');
            });
            mainNav.addEventListener('mouseenter', () => {
                mainNav.classList.remove('nav-hidden');
            });
            mainNav.addEventListener('mouseleave', () => {
                if (window.scrollY > 80) {
                    mainNav.classList.add('nav-hidden');
                }
            });
        }
    </script>

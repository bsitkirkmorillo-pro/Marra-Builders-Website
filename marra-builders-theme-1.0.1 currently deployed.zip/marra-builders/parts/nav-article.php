
    <!-- NAVIGATION BAR -->
    <header id="main-nav" class="fixed top-0 left-0 w-full z-40 bg-white/95 dark:bg-ink/95 backdrop-blur-md border-b border-black/[0.06] transition-transform duration-300 ease-in-out dark:border-white/10">
        <div class="max-w-6xl mx-auto px-6 h-20 flex items-center justify-between">

            <!-- Brand / Logo: automatically switches between black and white PNG in light/dark mode -->
            <a href="<?php echo esc_url(marra_url('home')); ?>" class="flex items-center group">
                <span class="relative inline-flex items-center h-10 transition-transform duration-300 group-hover:scale-105">
                    <img src="<?php echo esc_url(MARRA_ASSETS); ?>png/marra-builders-large-black.png" alt="Marra Builders Inc." class="h-10 w-auto dark:hidden">
                    <img src="<?php echo esc_url(MARRA_ASSETS); ?>png/marra-builders-large-white.png" alt="Marra Builders Inc." class="hidden h-10 w-auto dark:block">
                </span>
            </a>

            <!-- Right side: theme toggle + navigation on desktop; theme toggle + hamburger on mobile -->
            <div class="flex items-center gap-3 md:gap-5">

                <!-- Light/Dark Mode Toggle -->
                <button id="theme-toggle" type="button" aria-label="Toggle dark mode" class="inline-flex items-center justify-center h-11 w-11 min-h-[44px] min-w-[44px] rounded-lg text-slate-700 hover:text-brand dark:text-slate-100 dark:hover:text-accent-light hover:bg-slate-100 dark:hover:bg-white/10 active:scale-90 transition-all duration-200 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 dark:focus-visible:ring-offset-ink">
                    <svg data-theme-icon="sun" class="hidden h-5 w-5 transition-transform duration-200 hover:scale-110 hover:rotate-12" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l1.41 1.41"></path></svg>
                    <svg data-theme-icon="moon" class="h-5 w-5 transition-transform duration-200 hover:scale-110 hover:-rotate-12" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z"></path></svg>
                </button>

                <!-- Desktop Navigation -->
                <nav class="hidden md:flex items-center space-x-9 text-[12.5px] font-semibold uppercase tracking-[0.09em] text-slate-600 dark:text-slate-300">
                    <a href="<?php echo esc_url(marra_url('home')); ?>#" class="relative transition-colors duration-200 after:absolute after:left-0 after:-bottom-1 after:h-0.5 after:w-0 after:bg-accent after:transition-all after:duration-300 hover:after:w-full dark:hover:text-accent-light">Home</a> <a href="<?php echo esc_url(marra_url('home')); ?>#about" class="relative transition-colors duration-200 after:absolute after:left-0 after:-bottom-1 after:h-0.5 after:w-0 after:bg-accent after:transition-all after:duration-300 hover:after:w-full dark:hover:text-accent-light">About</a> <a href="<?php echo esc_url(marra_url('home')); ?>#services" class="relative transition-colors duration-200 after:absolute after:left-0 after:-bottom-1 after:h-0.5 after:w-0 after:bg-accent after:transition-all after:duration-300 hover:after:w-full dark:hover:text-accent-light">Services</a> <a href="<?php echo esc_url(marra_url('projects')); ?>" class="relative transition-colors duration-200 after:absolute after:left-0 after:-bottom-1 after:h-0.5 after:w-0 after:bg-accent after:transition-all after:duration-300 hover:after:w-full dark:hover:text-accent-light">Projects</a> <a href="<?php echo esc_url(marra_url('articles')); ?>" aria-current="page" class="relative text-brand font-semibold after:absolute after:left-0 after:-bottom-1 after:h-0.5 after:w-full after:bg-accent dark:text-accent-light">Articles</a> <a href="#footer" class="relative transition-colors duration-200 after:absolute after:left-0 after:-bottom-1 after:h-0.5 after:w-0 after:bg-accent after:transition-all after:duration-300 hover:after:w-full dark:hover:text-accent-light">Contact Us</a>
                </nav>

                <!-- Mobile Menu Toggle -->
                <button id="mobile-menu-btn" class="md:hidden text-slate-700 hover:text-brand focus:outline-none p-2 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg cursor-pointer transition-all duration-200 hover:bg-slate-100 active:scale-90 dark:text-slate-100 dark:hover:text-accent-light dark:hover:bg-ink-light" aria-label="Toggle Menu">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path id="menu-icon-bars" class="block" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                        <path id="menu-icon-close" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>

            </div>
        </div>

        <!-- Mobile Dropdown Menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-white border-b border-black/[0.06] px-6 py-6 shadow-xl space-y-4 text-left dark:bg-ink-light dark:border-white/10">
            <a href="<?php echo esc_url(marra_url('home')); ?>#" class="block text-slate-600 hover:text-brand font-medium py-2.5 px-2 -mx-2 rounded-lg transition-colors duration-150 hover:bg-slate-50 active:bg-slate-100 min-h-[44px] flex items-center cursor-pointer dark:text-slate-300 dark:hover:text-accent-light dark:hover:bg-ink-light dark:active:bg-ink-light">Home</a> <a href="<?php echo esc_url(marra_url('home')); ?>#about" class="block text-slate-600 hover:text-brand font-medium py-2.5 px-2 -mx-2 rounded-lg transition-colors duration-150 hover:bg-slate-50 active:bg-slate-100 min-h-[44px] flex items-center cursor-pointer dark:text-slate-300 dark:hover:text-accent-light dark:hover:bg-ink-light dark:active:bg-ink-light">About</a> <a href="<?php echo esc_url(marra_url('home')); ?>#services" class="block text-slate-600 hover:text-brand font-medium py-2.5 px-2 -mx-2 rounded-lg transition-colors duration-150 hover:bg-slate-50 active:bg-slate-100 min-h-[44px] flex items-center cursor-pointer dark:text-slate-300 dark:hover:text-accent-light dark:hover:bg-ink-light dark:active:bg-ink-light">Services</a> <a href="<?php echo esc_url(marra_url('projects')); ?>" class="block text-slate-600 hover:text-brand font-medium py-2.5 px-2 -mx-2 rounded-lg transition-colors duration-150 hover:bg-slate-50 active:bg-slate-100 min-h-[44px] flex items-center cursor-pointer dark:text-slate-300 dark:hover:text-accent-light dark:hover:bg-ink-light dark:active:bg-ink-light">Projects</a> <a href="<?php echo esc_url(marra_url('articles')); ?>" aria-current="page" class="block text-brand font-semibold py-2.5 px-2 -mx-2 rounded-lg bg-slate-50 min-h-[44px] flex items-center cursor-pointer dark:text-accent-light dark:bg-ink-light">Articles</a> <a href="#footer" class="block text-slate-600 hover:text-brand font-medium py-2.5 px-2 -mx-2 rounded-lg transition-colors duration-150 hover:bg-slate-50 active:bg-slate-100 min-h-[44px] flex items-center cursor-pointer dark:text-slate-300 dark:hover:text-accent-light dark:hover:bg-ink-light dark:active:bg-ink-light">Contact Us</a>
        </div>
    </header>

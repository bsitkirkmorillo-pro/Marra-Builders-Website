
    <main class="flex-grow">
        <!-- PAGE HEADER / HERO -->
        <header class="relative pt-36 md:pt-44 pb-20 md:pb-28 bg-ink text-white overflow-hidden text-left">
            <div class="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1541888946425-d0fbb186a5b7?q=80&w=1200')] bg-cover bg-center opacity-[0.16] [filter:grayscale(0.4)]"></div>
            <div class="absolute inset-0 bg-gradient-to-br from-brand/95 via-ink to-ink"></div>
            <div class="relative max-w-6xl mx-auto px-6 text-left">
                <h1 class="font-heading text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.05] max-w-2xl" data-reveal>&middot; Our Projects</h1>
                <div class="rule-hairline w-16 mt-8 mb-6 text-white/40" data-reveal></div>
                <p class="text-slate-300 text-base max-w-xl leading-relaxed" data-reveal>A record of PCAB Category AAA marine and civil works, from Batanes to Tawi-Tawi.</p>
            </div>
        </header>

        <!-- PORTFOLIO GRID -->
        <section class="py-24 bg-surface text-left dark:bg-ink-light">
            <div class="max-w-6xl mx-auto px-6 text-left">
                <div id="portfolio-grid" class="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 text-left">
<?php marra_render_project_grid(); ?>
            </div>
            </div>
        </section>
    </main>
    
    <!-- FOOTER -->

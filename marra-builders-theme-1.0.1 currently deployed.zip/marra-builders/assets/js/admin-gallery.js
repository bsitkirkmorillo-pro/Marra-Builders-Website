jQuery(function ($) {
	var $wrap = $('#marra-gallery');
	if (!$wrap.length) { return; }
	var $input = $('#marra_gallery_ids');
	var $list = $('#marra-gallery-list');
	var frame;

	function sync() {
		var ids = [];
		$list.children('li').each(function () { ids.push($(this).data('id')); });
		$input.val(ids.join(','));
	}

	$list.sortable({ items: '> li', update: sync });

	$list.on('click', '.marra-remove', function (e) {
		e.preventDefault();
		$(this).closest('li').remove();
		sync();
	});

	$('#marra-add-photos').on('click', function (e) {
		e.preventDefault();
		if (!frame) {
			frame = wp.media({
				title: 'Choose photos',
				button: { text: 'Add to gallery' },
				multiple: true,
				library: { type: 'image' }
			});
			frame.on('select', function () {
				frame.state().get('selection').each(function (att) {
					var a = att.toJSON();
					if ($list.find('li[data-id="' + a.id + '"]').length) { return; }
					var src = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
					var $li = $('<li></li>').attr('data-id', a.id);
					$li.append($('<img>').attr({ src: src, alt: '' }));
					$li.append($('<button type="button" class="marra-remove" aria-label="Remove photo">&times;</button>'));
					$list.append($li);
				});
				sync();
			});
		}
		frame.open();
	});
});

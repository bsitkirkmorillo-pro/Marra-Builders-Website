<?php
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', function () {
	add_menu_page( 'Site Content', 'Site Content', 'edit_pages', 'marra-content', 'marra_content_page', 'dashicons-edit-page', 20 );
} );

function marra_content_page() {
	if ( ! current_user_can( 'edit_pages' ) ) {
		wp_die( 'You do not have permission to open this page.' );
	}
	$defaults = marra_defaults();
	$saved    = get_option( 'marra_content', array() );
	$saved    = is_array( $saved ) ? $saved : array();
	$notice   = '';

	if ( isset( $_POST['marra_content_nonce'] ) ) {
		check_admin_referer( 'marra_content_save', 'marra_content_nonce' );
		$posted = isset( $_POST['marra_content'] ) && is_array( $_POST['marra_content'] ) ? wp_unslash( $_POST['marra_content'] ) : array();
		$new    = array();
		foreach ( $defaults as $key => $def ) {
			$val = isset( $posted[ $key ] ) ? sanitize_textarea_field( $posted[ $key ] ) : '';
			$val = trim( str_replace( "\r\n", "\n", $val ) );
			// Only keep a value when it differs from the original text.
			if ( '' !== $val && $val !== marra_default_plain( $key ) ) {
				$new[ $key ] = $val;
			}
		}
		update_option( 'marra_content', $new );
		if ( isset( $_POST['marra_contact_to'] ) ) {
			$valid = array();
			foreach ( preg_split( '/[\s,;]+/', (string) wp_unslash( $_POST['marra_contact_to'] ) ) as $addr ) {
				$addr = sanitize_email( $addr );
				if ( $addr && is_email( $addr ) && ! in_array( $addr, $valid, true ) ) {
					$valid[] = $addr;
				}
			}
			update_option( 'marra_contact_to', implode( ', ', $valid ) );
		}
		$saved  = $new;
		$notice = 'Saved. Your changes are now live on the website.';
	}

	$groups = array();
	foreach ( $defaults as $key => $def ) {
		$groups[ $def['group'] ][ $key ] = $def;
	}
	?>
	<div class="wrap">
		<h1>Site Content</h1>
		<p>Edit the texts of the home page and the contact details shown in the footer of every page. Leave a box as it is to keep the original text.</p>
		<?php if ( $notice ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php echo esc_html( $notice ); ?></p></div>
		<?php endif; ?>
		<form method="post">
			<?php wp_nonce_field( 'marra_content_save', 'marra_content_nonce' ); ?>

			<h2>Quote form</h2>
			<table class="form-table"><tbody><tr>
				<th><label for="marra_contact_to">Send quote requests to</label></th>
				<td>
					<input type="text" id="marra_contact_to" name="marra_contact_to" class="large-text" value="<?php echo esc_attr( get_option( 'marra_contact_to', '' ) ); ?>" placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>">
					<p class="description">You can enter more than one address, separated by commas (for example: first@example.com, second@example.com). Every request is also saved under <strong>Messages</strong>. Leave empty to use the WordPress admin email.</p>
				</td>
			</tr></tbody></table>

			<?php foreach ( $groups as $group => $fields ) : ?>
				<h2><?php echo esc_html( $group ); ?></h2>
				<table class="form-table"><tbody>
				<?php foreach ( $fields as $key => $def ) :
					$val  = isset( $saved[ $key ] ) ? $saved[ $key ] : marra_default_plain( $key );
					$rows = $def['long'] ? max( 3, min( 10, (int) ceil( strlen( $val ) / 90 ) + 1 ) ) : 1;
					?>
					<tr>
						<th><label for="mc-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $def['label'] ); ?></label></th>
						<td>
							<?php if ( $def['long'] ) : ?>
								<textarea id="mc-<?php echo esc_attr( $key ); ?>" name="marra_content[<?php echo esc_attr( $key ); ?>]" rows="<?php echo (int) $rows; ?>" class="large-text"><?php echo esc_textarea( $val ); ?></textarea>
							<?php else : ?>
								<input type="text" id="mc-<?php echo esc_attr( $key ); ?>" name="marra_content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $val ); ?>" class="large-text">
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody></table>
			<?php endforeach; ?>
			<?php submit_button( 'Save changes' ); ?>
		</form>
	</div>
	<?php
}

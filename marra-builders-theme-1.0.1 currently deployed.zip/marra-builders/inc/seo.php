<?php
defined( 'ABSPATH' ) || exit;

function marra_seo_context() {
	if ( is_front_page() || is_home() ) {
		return 'home';
	}
	if ( is_post_type_archive( 'marra_project' ) ) {
		return 'projects';
	}
	if ( is_post_type_archive( 'marra_article' ) ) {
		return 'articles';
	}
	if ( is_singular( 'marra_project' ) ) {
		return 'project';
	}
	if ( is_singular( 'marra_article' ) ) {
		return 'article';
	}
	return '';
}

function marra_seo_data() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$ctx  = marra_seo_context();
	$logo = MARRA_ASSETS . 'png/marra-builders-large-black.png';
	$def  = marra_json( 'seo-defaults.json' );
	$d    = array( 'ctx' => $ctx );

	if ( in_array( $ctx, array( 'home', 'projects', 'articles' ), true ) && isset( $def[ $ctx ] ) ) {
		$s = $def[ $ctx ];
		$d += array(
			'title'          => $s['title'],
			'description'    => $s['description'],
			'keywords'       => $s['keywords'],
			'og_title'       => $s['og_title'],
			'og_description' => $s['og_description'],
			'image'          => $logo,
			'url'            => 'home' === $ctx ? home_url( '/' ) : marra_url( $ctx ),
			'og_type'        => 'website',
		);
	} elseif ( in_array( $ctx, array( 'project', 'article' ), true ) && is_singular() ) {
		$pid   = get_queried_object_id();
		$title = get_the_title( $pid );
		$loc   = marra_location( $pid );
		list( $lead, $rest ) = marra_split_description( get_post_field( 'post_content', $pid ) );
		$fallback = 'project' === $ctx ? 'Explore this marine civil engineering project by Marra Builders Inc.' : 'Read this update from Marra Builders Inc.';
		$summary  = mb_substr( $lead ? $lead : $fallback, 0, 300 );
		$ids      = marra_image_ids( $pid );
		$image    = $ids ? wp_get_attachment_image_url( $ids[0], 'full' ) : $logo;
		$d += array(
			'title'          => $title . ' | Marra Builders Inc.',
			'description'    => $summary,
			'keywords'       => implode( ', ', array_filter( array( $title, $loc, 'Marra Builders Inc.', 'project' === $ctx ? 'marine civil engineering' : 'marine civil engineering news', 'Philippines' ) ) ),
			'og_title'       => $title . ' | Marra Builders Inc.',
			'og_description' => $summary,
			'image'          => $image ? $image : $logo,
			'url'            => get_permalink( $pid ),
			'og_type'        => 'project' === $ctx ? 'website' : 'article',
			'pid'            => $pid,
			'ids'            => $ids,
			'name'           => $title,
		);
	}
	$cache = $d;
	return $cache;
}

add_filter( 'pre_get_document_title', function ( $title ) {
	$d = marra_seo_data();
	return ! empty( $d['title'] ) ? $d['title'] : $title;
} );

function marra_ld( $data ) {
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}

add_action( 'wp_head', function () {
	$d = marra_seo_data();
	if ( empty( $d['title'] ) ) {
		return;
	}
	$site = untrailingslashit( home_url() );
	echo '<meta name="description" content="' . esc_attr( $d['description'] ) . '">' . "\n";
	echo '<meta name="keywords" content="' . esc_attr( $d['keywords'] ) . '">' . "\n";
	if ( in_array( $d['ctx'], array( 'home', 'projects', 'articles' ), true ) ) {
		echo '<link rel="canonical" href="' . esc_url( $d['url'] ) . '">' . "\n"; // singular pages get theirs from WordPress
	}
	echo '<meta property="og:type" content="' . esc_attr( $d['og_type'] ) . '">' . "\n";
	echo '<meta property="og:site_name" content="Marra Builders Inc.">' . "\n";
	echo '<meta property="og:locale" content="en_PH">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $d['og_title'] ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $d['og_description'] ) . '">' . "\n";
	echo '<meta property="og:image" content="' . esc_url( $d['image'] ) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( $d['url'] ) . '">' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<meta name="twitter:title" content="' . esc_attr( $d['og_title'] ) . '">' . "\n";
	echo '<meta name="twitter:description" content="' . esc_attr( $d['og_description'] ) . '">' . "\n";
	echo '<meta name="twitter:image" content="' . esc_url( $d['image'] ) . '">' . "\n";

	$ctx = $d['ctx'];
	if ( 'home' === $ctx ) {
		foreach ( marra_json( 'ld-home.json' ) as $raw ) {
			$obj = json_decode( str_replace( '{{SITE}}', $site, $raw ), true );
			if ( is_array( $obj ) ) {
				marra_ld( $obj );
			}
		}
	} elseif ( 'projects' === $ctx || 'articles' === $ctx ) {
		global $wp_query;
		$items = array();
		$pos   = 1;
		foreach ( (array) $wp_query->posts as $p ) {
			$items[] = array(
				'@type'    => 'ListItem',
				'position' => $pos++,
				'name'     => get_the_title( $p ),
				'url'      => get_permalink( $p ),
			);
		}
		marra_ld( array( '@context' => 'https://schema.org', '@type' => 'ItemList', 'itemListElement' => $items ) );
	} elseif ( 'project' === $ctx ) {
		$ids = $d['ids'];
		$imgs = array();
		foreach ( $ids as $id ) {
			$u = wp_get_attachment_image_url( $id, 'full' );
			if ( $u ) {
				$imgs[] = $u;
			}
		}
		$loc = marra_location( $d['pid'] );
		$ld  = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'CivilStructure',
			'name'        => $d['name'],
			'description' => $d['description'],
			'url'         => $d['url'],
			'image'       => $imgs ? $imgs : array( $d['image'] ),
			'address'     => array( '@type' => 'PostalAddress', 'addressCountry' => 'PH' ),
			'provider'    => array( '@id' => $site . '/#organization' ),
			'isPartOf'    => array( '@type' => 'WebSite', 'name' => 'Marra Builders Inc.', 'url' => $site . '/' ),
		);
		if ( $loc ) {
			$ld['address']['streetAddress'] = $loc;
		}
		marra_ld( $ld );
	} elseif ( 'article' === $ctx ) {
		$imgs = array();
		foreach ( $d['ids'] as $id ) {
			$u = wp_get_attachment_image_url( $id, 'full' );
			if ( $u ) {
				$imgs[] = $u;
			}
		}
		echo '<meta property="article:published_time" content="' . esc_attr( get_the_date( 'c', $d['pid'] ) ) . '">' . "\n";
		marra_ld( array(
			'@context'         => 'https://schema.org',
			'@type'            => 'BlogPosting',
			'headline'         => $d['name'],
			'description'      => $d['description'],
			'url'              => $d['url'],
			'image'            => $imgs ? $imgs : array( $d['image'] ),
			'datePublished'    => get_the_date( 'c', $d['pid'] ),
			'dateModified'     => get_the_modified_date( 'c', $d['pid'] ),
			'author'           => array( '@id' => $site . '/#organization' ),
			'publisher'        => array(
				'@type' => 'Organization',
				'name'  => 'Marra Builders Inc.',
				'logo'  => array( '@type' => 'ImageObject', 'url' => MARRA_ASSETS . 'png/marra-builders-large-black.png' ),
			),
			'mainEntityOfPage' => array( '@type' => 'WebPage', '@id' => $d['url'] ),
		) );
	}
}, 1 );

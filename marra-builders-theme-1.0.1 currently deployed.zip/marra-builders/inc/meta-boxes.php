<?php
defined( 'ABSPATH' ) || exit;

add_action( 'add_meta_boxes', function () {
	foreach ( array( 'marra_project' => 'Project details', 'marra_article' => 'Article details' ) as $pt => $label ) {
		add_meta_box( 'marra_details', $label, 'marra_details_box', $pt, 'normal', 'high' );
		add_meta_box( 'marra_gallery', 'More photos (gallery)', 'marra_gallery_box', $pt, 'normal', 'default' );
	}
	add_meta_box( 'marra_msg', 'Message details', 'marra_message_box', 'marra_message', 'normal', 'high' );
} );

function marra_details_box( $post ) {
	wp_nonce_field( 'marra_save_meta', 'marra_meta_nonce' );
	$is_project = 'marra_project' === $post->post_type;
	$loc  = marra_location( $post->ID );
	$feat = (bool) get_post_meta( $post->ID, '_marra_featured', true );
	?>
	<p>
		<label for="marra_location"><strong>Location</strong> <span style="color:#666">(the small gold line under the title<?php echo $is_project ? '' : ', e.g. Navotas City'; ?>)</span></label><br>
		<input type="text" id="marra_location" name="marra_location" value="<?php echo esc_attr( $loc ); ?>" style="width:100%" maxlength="200">
	</p>
	<p>
		<label><input type="checkbox" name="marra_featured" value="1" <?php checked( $feat ); ?>> <strong>Show on Home page</strong>
		<span style="color:#666">(up to 3 are shown; if none are ticked, the latest 3 appear)</span></label>
	</p>
	<p style="color:#666;margin-bottom:0">
		The <strong>title</strong> and <strong>description</strong> are the boxes above and below. Leave a blank line between paragraphs.
		The <strong>Featured image</strong> (right-hand side) is the main photo shown on the cards and at the top of the page.
	</p>
	<?php
}

function marra_gallery_box( $post ) {
	$g   = (string) get_post_meta( $post->ID, '_marra_gallery', true );
	$ids = array_filter( array_map( 'absint', explode( ',', $g ) ) );
	?>
	<div id="marra-gallery">
		<p style="color:#666;margin-top:0">Add the other photos here. Drag a photo to change the order; click &times; to remove it.</p>
		<ul id="marra-gallery-list">
			<?php foreach ( $ids as $id ) : ?>
				<li data-id="<?php echo (int) $id; ?>">
					<?php echo wp_get_attachment_image( $id, 'thumbnail' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<button type="button" class="marra-remove" aria-label="Remove photo">&times;</button>
				</li>
			<?php endforeach; ?>
		</ul>
		<input type="hidden" id="marra_gallery_ids" name="marra_gallery_ids" value="<?php echo esc_attr( implode( ',', $ids ) ); ?>">
		<button type="button" class="button button-primary" id="marra-add-photos">Add / choose photos</button>
	</div>
	<?php
}

function marra_save_meta( $post_id ) {
	if ( ! isset( $_POST['marra_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['marra_meta_nonce'] ) ), 'marra_save_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$loc = isset( $_POST['marra_location'] ) ? sanitize_text_field( wp_unslash( $_POST['marra_location'] ) ) : '';
	update_post_meta( $post_id, '_marra_location', $loc );
	if ( ! empty( $_POST['marra_featured'] ) ) {
		update_post_meta( $post_id, '_marra_featured', '1' );
	} else {
		delete_post_meta( $post_id, '_marra_featured' );
	}
	$g = isset( $_POST['marra_gallery_ids'] ) ? preg_replace( '/[^0-9,]/', '', wp_unslash( $_POST['marra_gallery_ids'] ) ) : '';
	update_post_meta( $post_id, '_marra_gallery', $g );
}
add_action( 'save_post_marra_project', 'marra_save_meta' );
add_action( 'save_post_marra_article', 'marra_save_meta' );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->post_type, array( 'marra_project', 'marra_article' ), true ) ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script( 'marra-admin-gallery', MARRA_ASSETS . 'js/admin-gallery.js', array( 'jquery', 'jquery-ui-sortable' ), MARRA_VERSION, true );
	wp_add_inline_style( 'wp-admin', '#marra-gallery-list{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 12px;padding:0;list-style:none}#marra-gallery-list li{position:relative;width:96px;height:96px;cursor:move;border:1px solid #c3c4c7;background:#f6f7f7}#marra-gallery-list img{width:100%;height:100%;object-fit:cover;display:block}.marra-remove{position:absolute;top:2px;right:2px;width:22px;height:22px;line-height:18px;padding:0;border:0;border-radius:50%;background:#b32d2e;color:#fff;font-size:16px;cursor:pointer}' );
} );

/* ---------- Messages (read-only) ---------- */
function marra_message_box( $post ) {
	$rows = array(
		'Name'         => get_post_meta( $post->ID, '_marra_name', true ),
		'Email'        => get_post_meta( $post->ID, '_marra_email', true ),
		'Phone'        => get_post_meta( $post->ID, '_marra_phone', true ),
		'Project type' => get_post_meta( $post->ID, '_marra_project_type', true ),
		'Received'     => get_the_date( 'F j, Y g:i a', $post ),
	);
	echo '<table class="form-table"><tbody>';
	foreach ( $rows as $k => $v ) {
		echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
	}
	echo '<tr><th>Message</th><td>' . nl2br( esc_html( get_post_meta( $post->ID, '_marra_message', true ) ) ) . '</td></tr>';
	echo '</tbody></table>';
}

add_filter( 'manage_marra_message_posts_columns', function () {
	return array(
		'cb'      => '<input type="checkbox" />',
		'title'   => 'From',
		'marra_e' => 'Email',
		'marra_p' => 'Phone',
		'marra_t' => 'Project type',
		'date'    => 'Received',
	);
} );
add_action( 'manage_marra_message_posts_custom_column', function ( $col, $post_id ) {
	$map = array( 'marra_e' => '_marra_email', 'marra_p' => '_marra_phone', 'marra_t' => '_marra_project_type' );
	if ( isset( $map[ $col ] ) ) {
		echo esc_html( get_post_meta( $post_id, $map[ $col ], true ) );
	}
}, 10, 2 );

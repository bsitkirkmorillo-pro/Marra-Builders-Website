<?php
defined( 'ABSPATH' ) || exit;

/** Page links used by the navigation. */
function marra_url( $which ) {
	if ( 'projects' === $which ) {
		$u = get_post_type_archive_link( 'marra_project' );
		return $u ? $u : home_url( '/projects/' );
	}
	if ( 'articles' === $which ) {
		$u = get_post_type_archive_link( 'marra_article' );
		return $u ? $u : home_url( '/articles/' );
	}
	return home_url( '/' );
}

/** Which of the original page layouts the current request uses. */
function marra_page_key() {
	if ( is_front_page() || is_home() ) {
		return 'home';
	}
	if ( is_post_type_archive( 'marra_project' ) ) {
		return 'portfolio';
	}
	if ( is_singular( 'marra_project' ) ) {
		return 'project';
	}
	if ( is_post_type_archive( 'marra_article' ) ) {
		return 'articles';
	}
	if ( is_singular( 'marra_article' ) ) {
		return 'article';
	}
	return 'portfolio';
}

function marra_json( $file ) {
	$path = MARRA_DIR . 'data/' . $file;
	if ( ! is_readable( $path ) ) {
		return array();
	}
	$data = json_decode( file_get_contents( $path ), true );
	return is_array( $data ) ? $data : array();
}

/* ---------- Editable site text ---------- */

function marra_defaults() {
	static $d = null;
	if ( null === $d ) {
		$d = marra_json( 'content-defaults.json' );
	}
	return $d;
}

/** Plain-text version of an original (default) text, for showing in the admin form. */
function marra_default_plain( $key ) {
	$d = marra_defaults();
	if ( ! isset( $d[ $key ]['default'] ) ) {
		return '';
	}
	$h = preg_replace( '#<br\s*/?>#i', "\n", $d[ $key ]['default'] );
	$h = html_entity_decode( wp_strip_all_tags( $h ), ENT_QUOTES, 'UTF-8' );
	$lines = array();
	foreach ( explode( "\n", $h ) as $line ) {
		$lines[] = trim( preg_replace( '/[ \t\r\n\x{00A0}]+/u', ' ', $line ) );
	}
	return trim( implode( "\n", $lines ) );
}

/** Output for a data-cms text: the saved value if any, otherwise the original text. */
function marra_text( $key ) {
	$saved = get_option( 'marra_content', array() );
	if ( is_array( $saved ) && isset( $saved[ $key ] ) && '' !== trim( $saved[ $key ] ) ) {
		return nl2br( esc_html( $saved[ $key ] ) );
	}
	$d = marra_defaults();
	return isset( $d[ $key ]['default'] ) ? $d[ $key ]['default'] : '';
}

/* ---------- Project / article data ---------- */

function marra_location( $post_id ) {
	return trim( (string) get_post_meta( $post_id, '_marra_location', true ) );
}

/** Photo IDs in display order: featured image first, then the gallery. */
function marra_image_ids( $post_id ) {
	$ids  = array();
	$feat = (int) get_post_thumbnail_id( $post_id );
	if ( $feat && wp_attachment_is_image( $feat ) ) {
		$ids[] = $feat;
	}
	$g = (string) get_post_meta( $post_id, '_marra_gallery', true );
	if ( '' !== $g ) {
		foreach ( array_filter( array_map( 'absint', explode( ',', $g ) ) ) as $id ) {
			if ( ! in_array( $id, $ids, true ) && wp_attachment_is_image( $id ) ) {
				$ids[] = $id;
			}
		}
	}
	return $ids;
}

/** Split the description into its first paragraph and the remaining ones (blank line = new paragraph). */
function marra_split_description( $content ) {
	$c = str_replace( array( "\r\n", "\r" ), "\n", (string) $content );
	$c = preg_replace( '#</p>\s*#i', "\n\n", $c );
	$c = preg_replace( '#<br\s*/?>#i', "\n", $c );
	$c = html_entity_decode( wp_strip_all_tags( $c ), ENT_QUOTES, 'UTF-8' );
	$parts = preg_split( '/\n\s*\n/', trim( $c ) );
	$parts = array_values( array_filter( array_map( 'trim', $parts ), 'strlen' ) );
	return array( $parts ? $parts[0] : '', array_slice( $parts, 1 ) );
}

function marra_plain_description( $post_id ) {
	list( $lead, $rest ) = marra_split_description( get_post_field( 'post_content', $post_id ) );
	return trim( $lead . ( $rest ? "\n\n" . implode( "\n\n", $rest ) : '' ) );
}

function marra_image_alt( $title, $loc, $i, $n ) {
	$parts = array( $title ? $title : 'Marine civil engineering project' );
	if ( $loc ) {
		$parts[] = $loc;
	}
	$alt = implode( ' — ', $parts );
	if ( $n > 1 ) {
		$alt .= ' (photo ' . ( $i + 1 ) . ' of ' . $n . ')';
	}
	return $alt . ' | Marra Builders Inc.';
}

/** Photos on a detail page: first one full width, the rest in a two-column grid. */
function marra_render_gallery( $ids, $title, $loc ) {
	$n         = count( $ids );
	$grid_open = false;
	$base      = 'rounded-md overflow-hidden shadow-elevated bg-slate-200 border border-black/[0.06] dark:bg-white/10 dark:border-white/10';
	foreach ( $ids as $i => $id ) {
		$img = wp_get_attachment_image( $id, 0 === $i ? 'full' : 'large', false, array(
			'class'    => 'w-full h-full object-cover',
			'alt'      => marra_image_alt( $title, $loc, $i, $n ),
			'loading'  => 0 === $i ? 'eager' : 'lazy',
			'decoding' => 'async',
		) );
		if ( ! $img ) {
			continue;
		}
		if ( 0 === $i ) {
			echo '<div class="' . esc_attr( $base ) . ' aspect-[16/9]">' . $img . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		} else {
			if ( ! $grid_open ) {
				echo '<div class="grid sm:grid-cols-2 gap-6">';
				$grid_open = true;
			}
			echo '<div class="' . esc_attr( $base ) . ' aspect-[4/3]">' . $img . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}
	if ( $grid_open ) {
		echo '</div>';
	}
}

<?php
defined( 'ABSPATH' ) || exit;

/**
 * One-time importer: Tools > Marra Import.
 * Creates the original 17 projects and 1 article from data/import.json and
 * loads their photos from wp-content/uploads/marra-import/ into the Media Library.
 */

function marra_import_dir() {
	$u = wp_upload_dir();
	return trailingslashit( $u['basedir'] ) . 'marra-import/';
}

add_action( 'admin_menu', function () {
	add_management_page( 'Marra Import', 'Marra Import', 'manage_options', 'marra-import', 'marra_import_page' );
} );

function marra_import_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'You do not have permission to open this page.' );
	}
	$items = marra_json( 'import.json' );
	$dir   = marra_import_dir();
	$need  = array();
	foreach ( $items as $it ) {
		foreach ( $it['images'] as $f ) {
			$need[ $f ] = true;
		}
	}
	$found = 0;
	foreach ( array_keys( $need ) as $f ) {
		if ( is_readable( $dir . $f ) ) {
			$found++;
		}
	}
	$done = 0;
	foreach ( $items as $it ) {
		$e = get_posts( array( 'post_type' => $it['type'], 'post_status' => 'any', 'meta_key' => '_marra_source_id', 'meta_value' => $it['source'], 'fields' => 'ids', 'posts_per_page' => 1 ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( $e ) {
			$done++;
		}
	}
	$nonce = wp_create_nonce( 'marra_import' );
	?>
	<div class="wrap">
		<h1>Marra Import</h1>
		<p>This copies the original website content into WordPress: <strong><?php echo (int) count( $items ); ?> items</strong> (projects and articles) with their photos. It is safe to run again: items that already exist are skipped.</p>
		<table class="widefat striped" style="max-width:640px"><tbody>
			<tr><td>Items already imported</td><td><strong><?php echo (int) $done; ?></strong> of <?php echo (int) count( $items ); ?></td></tr>
			<tr><td>Photos found in the import folder</td><td><strong><?php echo (int) $found; ?></strong> of <?php echo (int) count( $need ); ?></td></tr>
			<tr><td>Import folder</td><td><code>wp-content/uploads/marra-import/</code></td></tr>
		</tbody></table>
		<?php if ( $found < count( $need ) ) : ?>
			<div class="notice notice-warning inline"><p>Some photos are not in the import folder yet. You can still import now, but those photos will be missing. Upload the photos first for a complete import.</p></div>
		<?php endif; ?>
		<p><button type="button" class="button button-primary button-hero" id="marra-import-start"><?php echo $done ? 'Run import again' : 'Start import'; ?></button></p>
		<div id="marra-import-log" style="max-width:640px;max-height:360px;overflow:auto;background:#fff;border:1px solid #c3c4c7;padding:8px 12px;display:none;font-family:monospace;font-size:12px"></div>
	</div>
	<script>
	(function () {
		var btn = document.getElementById('marra-import-start');
		var log = document.getElementById('marra-import-log');
		var total = <?php echo (int) count( $items ); ?>;
		var i = 0;
		function line(t, bad) {
			var d = document.createElement('div');
			d.textContent = t;
			if (bad) { d.style.color = '#b32d2e'; }
			log.appendChild(d);
			log.scrollTop = log.scrollHeight;
		}
		function step() {
			var fd = new FormData();
			fd.append('action', 'marra_import_step');
			fd.append('index', i);
			fd.append('_wpnonce', <?php echo wp_json_encode( $nonce ); ?>);
			fetch(<?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>, { method: 'POST', body: fd, credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (d) {
					var msg = (d && d.data && d.data.message) ? d.data.message : 'Unexpected response';
					if (!d || !d.success) { line((i + 1) + '/' + total + '  FAILED: ' + msg, true); btn.disabled = false; btn.textContent = 'Retry from item ' + (i + 1); return; }
					line((i + 1) + '/' + total + '  ' + msg);
					i++;
					if (i < total) { step(); } else { line('Finished.'); btn.textContent = 'Finished'; }
				})
				.catch(function () { line('Connection problem at item ' + (i + 1) + '. Click the button to retry.', true); btn.disabled = false; btn.textContent = 'Retry from item ' + (i + 1); });
		}
		btn.addEventListener('click', function () {
			btn.disabled = true;
			log.style.display = 'block';
			step();
		});
	})();
	</script>
	<?php
}

add_action( 'wp_ajax_marra_import_step', function () {
	check_ajax_referer( 'marra_import', '_wpnonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'Not allowed.' ), 403 );
	}
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 180 ); // phpcs:ignore
	}
	$items = marra_json( 'import.json' );
	$i     = isset( $_POST['index'] ) ? absint( $_POST['index'] ) : 0;
	if ( ! isset( $items[ $i ] ) ) {
		wp_send_json_error( array( 'message' => 'Unknown item.' ) );
	}
	$it = $items[ $i ];

	$exists = get_posts( array( 'post_type' => $it['type'], 'post_status' => 'any', 'meta_key' => '_marra_source_id', 'meta_value' => $it['source'], 'fields' => 'ids', 'posts_per_page' => 1 ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	if ( $exists ) {
		wp_send_json_success( array( 'message' => 'Already there, skipped: ' . $it['title'] ) );
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$postarr = array(
		'post_type'    => $it['type'],
		'post_status'  => 'publish',
		'post_title'   => wp_slash( $it['title'] ),
		'post_content' => wp_slash( $it['description'] ),
		'menu_order'   => (int) $it['order'],
	);
	if ( ! empty( $it['date'] ) ) {
		$postarr['post_date'] = $it['date'] . ' 00:00:00';
	}
	$pid = wp_insert_post( $postarr, true );
	if ( is_wp_error( $pid ) ) {
		wp_send_json_error( array( 'message' => $pid->get_error_message() ) );
	}
	update_post_meta( $pid, '_marra_source_id', $it['source'] );
	update_post_meta( $pid, '_marra_location', wp_slash( $it['location'] ) );
	if ( ! empty( $it['featured'] ) ) {
		update_post_meta( $pid, '_marra_featured', '1' );
	}

	$dir     = marra_import_dir();
	$att     = array();
	$missing = 0;
	foreach ( $it['images'] as $f ) {
		$path = $dir . $f;
		if ( ! is_readable( $path ) ) {
			$missing++;
			continue;
		}
		$tmp = wp_tempnam( $f );
		if ( ! $tmp || ! copy( $path, $tmp ) ) {
			$missing++;
			continue;
		}
		$aid = media_handle_sideload( array( 'name' => $f, 'tmp_name' => $tmp ), $pid, $it['title'] );
		if ( is_wp_error( $aid ) ) {
			@unlink( $tmp ); // phpcs:ignore
			$missing++;
			continue;
		}
		update_post_meta( $aid, '_wp_attachment_image_alt', wp_slash( $it['title'] ) );
		$att[ $f ] = $aid;
	}
	$thumb = ( $it['thumbnail'] && isset( $att[ $it['thumbnail'] ] ) ) ? $att[ $it['thumbnail'] ] : ( $att ? reset( $att ) : 0 );
	if ( $thumb ) {
		set_post_thumbnail( $pid, $thumb );
	}
	$gallery = array();
	foreach ( $it['images'] as $f ) {
		if ( isset( $att[ $f ] ) && $att[ $f ] !== $thumb ) {
			$gallery[] = $att[ $f ];
		}
	}
	update_post_meta( $pid, '_marra_gallery', implode( ',', $gallery ) );

	$msg = 'Imported: ' . $it['title'] . ' (' . count( $att ) . ' photos' . ( $missing ? ', ' . $missing . ' MISSING' : '' ) . ')';
	wp_send_json_success( array( 'message' => $msg ) );
} );

<?php
defined( 'ABSPATH' ) || exit;

function marra_register_post_types() {
	register_post_type( 'marra_project', array(
		'labels'        => array(
			'name'               => 'Projects',
			'singular_name'      => 'Project',
			'add_new'            => 'Add New Project',
			'add_new_item'       => 'Add New Project',
			'edit_item'          => 'Edit Project',
			'new_item'           => 'New Project',
			'view_item'          => 'View Project',
			'search_items'       => 'Search Projects',
			'not_found'          => 'No projects found.',
			'not_found_in_trash' => 'No projects found in Trash.',
			'all_items'          => 'All Projects',
			'menu_name'          => 'Projects',
		),
		'public'        => true,
		'has_archive'   => 'projects',
		'rewrite'       => array( 'slug' => 'projects', 'with_front' => false ),
		'menu_position' => 21,
		'menu_icon'     => 'dashicons-building',
		'supports'      => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		'show_in_rest'  => false, // simple classic editor: title + description + photos
	) );

	register_post_type( 'marra_article', array(
		'labels'        => array(
			'name'               => 'Articles',
			'singular_name'      => 'Article',
			'add_new'            => 'Add New Article',
			'add_new_item'       => 'Add New Article',
			'edit_item'          => 'Edit Article',
			'new_item'           => 'New Article',
			'view_item'          => 'View Article',
			'search_items'       => 'Search Articles',
			'not_found'          => 'No articles found.',
			'not_found_in_trash' => 'No articles found in Trash.',
			'all_items'          => 'All Articles',
			'menu_name'          => 'Articles',
		),
		'public'        => true,
		'has_archive'   => 'articles',
		'rewrite'       => array( 'slug' => 'articles', 'with_front' => false ),
		'menu_position' => 22,
		'menu_icon'     => 'dashicons-media-document',
		'supports'      => array( 'title', 'editor', 'thumbnail' ),
		'show_in_rest'  => false,
	) );

	// Messages sent from the quote form (admin only, never public).
	register_post_type( 'marra_message', array(
		'labels'          => array(
			'name'          => 'Messages',
			'singular_name' => 'Message',
			'all_items'     => 'All Messages',
			'menu_name'     => 'Messages',
			'edit_item'     => 'View Message',
			'search_items'  => 'Search Messages',
			'not_found'     => 'No messages yet.',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_position'   => 23,
		'menu_icon'       => 'dashicons-email-alt',
		'supports'        => array( 'title' ),
		'capability_type' => 'post',
		'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
		'map_meta_cap'    => true,
		'show_in_rest'    => false,
	) );
}
add_action( 'init', 'marra_register_post_types' );

/** Show every project/article on its list page, in the original order. */
add_action( 'pre_get_posts', function ( $q ) {
	if ( ! $q->is_main_query() ) {
		return;
	}
	if ( is_admin() ) {
		if ( 'marra_project' === $q->get( 'post_type' ) && ! isset( $_GET['orderby'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$q->set( 'orderby', 'menu_order title' );
			$q->set( 'order', 'ASC' );
		}
		return;
	}
	if ( $q->is_post_type_archive( 'marra_project' ) ) {
		$q->set( 'posts_per_page', -1 );
		$q->set( 'orderby', array( 'menu_order' => 'ASC', 'date' => 'DESC' ) );
	}
	if ( $q->is_post_type_archive( 'marra_article' ) ) {
		$q->set( 'posts_per_page', -1 );
		$q->set( 'orderby', 'date' );
		$q->set( 'order', 'DESC' );
	}
} );

/** Handy columns in the admin lists. */
foreach ( array( 'marra_project', 'marra_article' ) as $marra_pt ) {
	add_filter( "manage_{$marra_pt}_posts_columns", function ( $cols ) {
		$new = array();
		foreach ( $cols as $k => $v ) {
			if ( 'title' === $k ) {
				$new['marra_thumb'] = 'Photo';
			}
			$new[ $k ] = $v;
			if ( 'title' === $k ) {
				$new['marra_location'] = 'Location';
				$new['marra_featured'] = 'On Home page';
			}
		}
		return $new;
	} );
	add_action( "manage_{$marra_pt}_posts_custom_column", function ( $col, $post_id ) {
		if ( 'marra_thumb' === $col ) {
			echo get_the_post_thumbnail( $post_id, array( 60, 60 ) ); // phpcs:ignore WordPress.Security.EscapeOutput
		} elseif ( 'marra_location' === $col ) {
			echo esc_html( marra_location( $post_id ) );
		} elseif ( 'marra_featured' === $col ) {
			echo get_post_meta( $post_id, '_marra_featured', true ) ? 'Yes' : '&mdash;';
		}
	}, 10, 2 );
}

<?php
defined( 'ABSPATH' ) || exit;

/** CSS classes of the original cards (copied from the original pages). */
function marra_card_classes() {
	static $c = null;
	if ( null === $c ) {
		$c = json_decode( <<<'JSON'
{
 "home_proj": {
  "card": "bg-white rounded-md overflow-hidden shadow-soft border border-black/[0.06] group text-left transition-all duration-300 hover:shadow-elevated hover:-translate-y-1.5 active:scale-[0.99] cursor-pointer animate-fadeInUp flex flex-col justify-between focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 dark:bg-ink-light dark:border-white/10",
  "imgc": "h-64 bg-slate-200 overflow-hidden relative dark:bg-white/10",
  "content": "p-8 text-left flex-1 flex flex-col justify-between",
  "meta": "flex items-center gap-2 text-[11px] font-bold text-accent uppercase tracking-widest mb-3 text-left dark:text-accent-light",
  "title": "text-xl font-bold text-slate-900 tracking-tight leading-snug mb-2 text-left group-hover:text-brand transition-colors duration-200 dark:text-white dark:group-hover:text-accent-light",
  "desc": "text-slate-600 text-sm leading-relaxed text-left line-clamp-3 dark:text-slate-300",
  "more": "mt-6 pt-4 border-t border-slate-100 flex items-center dark:border-white/10",
  "morehtml": "<span class=\"card-link project-card-link\"><span class=\"card-link__text\">View Project</span><svg class=\"card-link__arrow\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M14 5l7 7m0 0l-7 7m7-7H3\"></path></svg></span>",
  "img": "w-full h-full object-cover group-hover:scale-105 transition duration-500"
 },
 "home_art": {
  "card": "bg-white rounded-md overflow-hidden shadow-soft border border-black/[0.06] group text-left transition-all duration-300 hover:shadow-elevated hover:-translate-y-1.5 active:scale-[0.99] cursor-pointer animate-fadeInUp flex flex-col justify-between focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 dark:bg-ink-light dark:border-white/10",
  "imgc": "h-64 bg-slate-200 overflow-hidden relative dark:bg-white/10",
  "content": "p-8 text-left flex-1 flex flex-col justify-between",
  "meta": "flex items-center justify-between text-[11px] font-semibold text-accent uppercase tracking-widest mb-3 text-left",
  "title": "text-xl font-bold text-slate-900 tracking-tight leading-snug mb-2 text-left group-hover:text-brand transition-colors duration-200 dark:text-white dark:group-hover:text-accent-light",
  "desc": "text-slate-600 text-sm leading-relaxed text-left line-clamp-3 dark:text-slate-300",
  "more": "mt-6 pt-4 border-t border-slate-100 flex items-center dark:border-white/10",
  "morehtml": "<span class=\"card-link article-card-link\"><span class=\"card-link__text\">Read Article</span><svg class=\"card-link__arrow\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M14 5l7 7m0 0l-7 7m7-7H3\"></path></svg></span>",
  "img": "w-full h-full object-cover group-hover:scale-105 transition duration-500"
 },
 "list_proj": {
  "card": "bg-white rounded-md overflow-hidden shadow-soft border border-black/[0.06] group text-left transition-all duration-300 hover:shadow-elevated hover:-translate-y-1.5 active:scale-[0.99] cursor-pointer animate-fadeInUp flex flex-col justify-between focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 dark:bg-ink-light dark:border-white/10",
  "imgc": "h-64 bg-slate-200 overflow-hidden relative dark:bg-white/10",
  "content": "p-8 text-left flex-1 flex flex-col justify-between",
  "meta": "flex items-center gap-2 text-[11px] font-bold text-accent uppercase tracking-widest mb-3 text-left dark:text-accent-light",
  "title": "text-xl font-bold text-slate-900 tracking-tight leading-snug mb-2 text-left group-hover:text-brand transition-colors duration-200 dark:text-white dark:group-hover:text-accent-light",
  "desc": "text-slate-600 text-sm leading-relaxed text-left line-clamp-3 dark:text-slate-300",
  "more": "mt-6 pt-4 border-t border-slate-100 flex items-center dark:border-white/10",
  "morehtml": "<span class=\"card-link project-card-link\"><span class=\"card-link__text\">View Project</span><svg class=\"card-link__arrow\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M14 5l7 7m0 0l-7 7m7-7H3\"></path></svg></span>",
  "img": "w-full h-full object-cover group-hover:scale-105 transition duration-500"
 },
 "list_art": {
  "card": "bg-white rounded-md overflow-hidden shadow-soft border border-black/[0.06] group text-left transition-all duration-300 hover:shadow-elevated hover:-translate-y-1.5 active:scale-[0.99] cursor-pointer animate-fadeInUp flex flex-col justify-between focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 dark:bg-ink-light dark:border-white/10",
  "imgc": "h-64 bg-slate-200 overflow-hidden relative dark:bg-white/10",
  "content": "p-8 text-left flex-1 flex flex-col justify-between",
  "meta": "flex items-center justify-between text-[11px] font-semibold text-accent uppercase tracking-widest mb-3 text-left",
  "title": "text-xl font-bold text-slate-900 tracking-tight leading-snug mb-2 text-left group-hover:text-brand transition-colors duration-200 dark:text-white dark:group-hover:text-accent-light",
  "desc": "text-slate-600 text-sm leading-relaxed text-left line-clamp-3 dark:text-slate-300",
  "more": "mt-6 pt-4 border-t border-slate-100 flex items-center dark:border-white/10",
  "morehtml": "<span class=\"card-link article-card-link\"><span class=\"card-link__text\">Read Article</span><svg class=\"card-link__arrow\" fill=\"none\" stroke=\"currentColor\" viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M14 5l7 7m0 0l-7 7m7-7H3\"></path></svg></span>",
  "img": "w-full h-full object-cover group-hover:scale-105 transition duration-500"
 }
}
JSON
		, true );
	}
	return $c;
}

/**
 * One project or article card.
 * $kind: 'project' | 'article'   $ctx: 'home' | 'list'
 */
function marra_render_card( $post_id, $kind, $ctx, $index ) {
	$all = marra_card_classes();
	$c   = $all[ $ctx . '_' . ( 'project' === $kind ? 'proj' : 'art' ) ];
	$title = get_the_title( $post_id );
	$loc   = marra_location( $post_id );
	$ids   = marra_image_ids( $post_id );
	$alt   = trim( $title . ( $loc ? ' — ' . $loc : '' ) ) . ' | Marra Builders Inc.';
	?>
<a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" class="<?php echo esc_attr( $c['card'] ); ?>" style="animation-delay:<?php echo (int) $index * 60; ?>ms">
	<div class="<?php echo esc_attr( $c['imgc'] ); ?>">
		<?php
		$img = $ids ? wp_get_attachment_image( $ids[0], 'large', false, array(
			'class'    => $c['img'],
			'alt'      => $alt,
			'loading'  => 'lazy',
			'decoding' => 'async',
		) ) : '';
		if ( $img ) {
			echo $img; // phpcs:ignore WordPress.Security.EscapeOutput
		} else {
			echo '<div class="w-full h-full flex items-center justify-center text-slate-500 text-sm text-center p-4 dark:text-slate-400">No image available</div>';
		}
		?>
	</div>
	<div class="<?php echo esc_attr( $c['content'] ); ?>">
		<div>
			<h3 class="<?php echo esc_attr( $c['title'] ); ?>"><?php echo esc_html( $title ); ?></h3>
			<div class="<?php echo esc_attr( $c['meta'] ); ?>"><span><?php echo esc_html( $loc ); ?></span></div>
			<p class="<?php echo esc_attr( $c['desc'] ); ?>"><?php echo esc_html( marra_plain_description( $post_id ) ); ?></p>
		</div>
		<div class="<?php echo esc_attr( $c['more'] ); ?>"><?php echo $c['morehtml']; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
	</div>
</a>
	<?php
}

/** Home page: items ticked "Show on Home page" (latest ones if none are ticked), max 3. */
function marra_render_home( $post_type, $kind, $empty_text ) {
	$order = 'marra_project' === $post_type
		? array( 'menu_order' => 'ASC', 'date' => 'DESC' )
		: array( 'date' => 'DESC' );
	$args  = array(
		'post_type'      => $post_type,
		'post_status'    => 'publish',
		'posts_per_page' => 3,
		'orderby'        => $order,
		'no_found_rows'  => true,
		'meta_key'       => '_marra_featured', // phpcs:ignore WordPress.DB.SlowDBQuery
		'meta_value'     => '1',              // phpcs:ignore WordPress.DB.SlowDBQuery
	);
	$q = new WP_Query( $args );
	if ( ! $q->have_posts() ) {
		unset( $args['meta_key'], $args['meta_value'] );
		$q = new WP_Query( $args );
	}
	if ( ! $q->have_posts() ) {
		echo '<p class="col-span-full text-center text-slate-500 py-10 dark:text-slate-400">' . esc_html( $empty_text ) . '</p>';
		return;
	}
	$i = 0;
	while ( $q->have_posts() ) {
		$q->the_post();
		marra_render_card( get_the_ID(), $kind, 'home', $i++ );
	}
	wp_reset_postdata();
}
function marra_render_home_projects() {
	marra_render_home( 'marra_project', 'project', 'No projects found.' );
}
function marra_render_home_articles() {
	marra_render_home( 'marra_article', 'article', 'No articles to show right now.' );
}

/** Full list pages (main query). */
function marra_render_project_grid() {
	if ( ! have_posts() ) {
		echo '<div class="col-span-full text-center py-16"><p class="text-slate-600 font-medium dark:text-slate-300">No projects to show right now.</p><p class="text-slate-400 text-sm mt-1 dark:text-slate-500">Please check back soon, or reach out directly.</p><a href="#footer" class="inline-block mt-5 text-xs font-semibold text-brand hover:text-accent transition-colors dark:text-accent-light">Contact our team &rarr;</a></div>';
		return;
	}
	$i = 0;
	while ( have_posts() ) {
		the_post();
		marra_render_card( get_the_ID(), 'project', 'list', $i++ );
	}
}
function marra_render_article_grid() {
	if ( ! have_posts() ) {
		echo '<div class="col-span-full text-center py-16"><p class="text-slate-600 font-medium dark:text-slate-300">No articles to show right now.</p><p class="text-slate-400 text-sm mt-1 dark:text-slate-500">Please check back soon.</p></div>';
		return;
	}
	$i = 0;
	while ( have_posts() ) {
		the_post();
		marra_render_card( get_the_ID(), 'article', 'list', $i++ );
	}
}

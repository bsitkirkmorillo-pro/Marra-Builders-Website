<?php
defined( 'ABSPATH' ) || exit;

add_action( 'wp_ajax_nopriv_marra_contact', 'marra_handle_contact' );
add_action( 'wp_ajax_marra_contact', 'marra_handle_contact' );

/** Quote / contact form: validates, saves under "Messages" and emails the office. */
function marra_handle_contact() {
	// Honeypot: real visitors never tick this hidden box.
	if ( ! empty( $_POST['botcheck'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		wp_send_json_success();
	}

	$ip   = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';
	$key  = 'marra_rl_' . md5( $ip );
	$hits = (int) get_transient( $key );
	if ( $hits >= 6 ) {
		wp_send_json_error( array( 'message' => 'Too many messages. Please try again later.' ), 429 );
	}

	// phpcs:disable WordPress.Security.NonceVerification
	$name    = isset( $_POST['name'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['name'] ) ), 0, 120 ) : '';
	$email   = isset( $_POST['email'] ) ? mb_substr( sanitize_email( wp_unslash( $_POST['email'] ) ), 0, 200 ) : '';
	$phone   = isset( $_POST['phone'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['phone'] ) ), 0, 40 ) : '';
	$ptype   = isset( $_POST['project_type'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['project_type'] ) ), 0, 120 ) : '';
	$message = isset( $_POST['message'] ) ? mb_substr( sanitize_textarea_field( wp_unslash( $_POST['message'] ) ), 0, 5000 ) : '';
	// phpcs:enable

	if ( '' === $name || ! is_email( $email ) || ! preg_match( '/^[0-9+()\-\s]{7,20}$/', $phone ) || '' === $ptype || '' === $message ) {
		wp_send_json_error( array( 'message' => 'Please complete all required fields.' ), 400 );
	}

	set_transient( $key, $hits + 1, HOUR_IN_SECONDS );

	$id = wp_insert_post( array(
		'post_type'   => 'marra_message',
		'post_status' => 'publish',
		'post_title'  => wp_slash( $name . ' — ' . $ptype ),
		'meta_input'  => array(
			'_marra_name'         => wp_slash( $name ),
			'_marra_email'        => wp_slash( $email ),
			'_marra_phone'        => wp_slash( $phone ),
			'_marra_project_type' => wp_slash( $ptype ),
			'_marra_message'      => wp_slash( $message ),
		),
	), true );
	if ( is_wp_error( $id ) ) {
		wp_send_json_error( array( 'message' => 'Could not save your message.' ), 500 );
	}

	$to = array();
	foreach ( preg_split( '/[\s,;]+/', (string) get_option( 'marra_contact_to', '' ) ) as $addr ) {
		if ( is_email( $addr ) ) {
			$to[] = $addr;
		}
	}
	if ( ! $to ) {
		$to = array( get_option( 'admin_email' ) );
	}
	$body = "New quote request from the website\n\n"
		. "Name: $name\nEmail: $email\nPhone: $phone\nProject type: $ptype\n\nMessage:\n$message\n";
	wp_mail(
		$to,
		'Website quote request: ' . $ptype . ' (' . $name . ')',
		$body,
		array( 'Reply-To: ' . $name . ' <' . $email . '>' )
	);

	wp_send_json_success();
}
